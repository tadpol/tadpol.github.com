/*
Copyright 2004, Michael Conrad Tadpol Tilstra <tadpol@tadpol.org>
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions, and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions, and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. The name of the author may not be used to endorse or promote products
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE AUTHOR "AS IS" AND ANY EXPRESS OR
IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
OF TITLE, NON-INFRINGEMENT, MERCHANTABILITY AND FITNESS FOR A PARTICULAR
PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY
DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR
TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.    
*/

#import "AppController.h"
#import "PreferenceController.h"
#import "AboutThis.h"
#import "GrowlDefines.h"

@implementation AppController

+ (void)initialize
{
	NSMutableDictionary *def = [NSMutableDictionary dictionary];
	[def setObject:[NSNumber numberWithBool:YES] forKey:MCTTBounce];
	[def setObject:[NSNumber numberWithBool:NO] forKey:MCTTAlert];
	[def setObject:[NSNumber numberWithBool:YES] forKey:MCTTGrowl];
	[def setObject:[NSArray arrayWithObjects:@"03:00", @"05:00", @"10:00", nil]
		forKey:MCTTTimeList];
	[[NSUserDefaults standardUserDefaults] registerDefaults: def];
	
	
	NSString *p = [[NSBundle mainBundle] pathForImageResource:@"ttt"];
	NSImage *img = [[NSImage alloc] initWithContentsOfFile:p];
	NSArray *objects = [NSArray arrayWithObject:@"Timer Finished" ];
	NSDictionary * growlReg = [NSDictionary dictionaryWithObjectsAndKeys:
										@"Tadpol's Tea Timer", GROWL_APP_NAME,
										objects, GROWL_NOTIFICATIONS_ALL,
										objects, GROWL_NOTIFICATIONS_DEFAULT,
										[img TIFFRepresentation], GROWL_APP_ICON,
										nil];
	[[NSDistributedNotificationCenter defaultCenter] 
		postNotificationName:GROWL_APP_REGISTRATION 
		object:nil
		userInfo:growlReg];

}

- (IBAction)showPreferencePanel:(id)sender
{
    if (!preferenceController) {
        preferenceController = [[PreferenceController alloc] init];
    }
    [preferenceController showWindow:self];
}
- (IBAction)showAboutThis:(id)sender
{
    if (!aboutThis) {
        aboutThis = [[AboutThis alloc] init];
    }
    [aboutThis showWindow:self];
}
- (void)dealloc
{
    [preferenceController release];
    [aboutThis release];
    [super dealloc];
}

@end
