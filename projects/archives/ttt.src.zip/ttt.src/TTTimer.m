/*
Copyright 2004, Michael Conrad Tadpol Tilstra <tadpol@tadpol.org>
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions, and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions, and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. The name of the author may not be used to endorse or promote products
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE AUTHOR "AS IS" AND ANY EXPRESS OR
IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
OF TITLE, NON-INFRINGEMENT, MERCHANTABILITY AND FITNESS FOR A PARTICULAR
PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY
DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR
TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.    
*/
#import "TTTimer.h"
#import "PreferenceController.h"
#import "GrowlDefines.h"

@implementation TTTimer

- init
{
	if (self = [super init]) {
		tres = [[NSMutableArray alloc] init];
		[tres addObject:@"00:00"];
		[tres retain];
	}
	return self;
}

- (void)dealloc
{
	[tres release];
	[super dealloc];
}

- (void)awakeFromNib
{
	[tres setArray:[[NSUserDefaults standardUserDefaults] arrayForKey:MCTTTimeList]];
	[[timer cell] reloadData];
	[[timer cell] setStringValue:[tres objectAtIndex:0]];
}

- (IBAction)startTimer:(id)sender
{
	/* Record message, Record time.
	 * Start a thread
	 * sleep for time
	 * pop alert with message.
	 */
	NSString *msg;
	NSArray *workspace;
	NSTimeInterval wait = 0.3;
	NSTimer *newtimer;
	
	msg = [[message stringValue] retain]; /* save the string. */
	
	/* Need to get the string value, then parse it into seconds. */
	/* TODO Need to vaildate the format of the time and report error if wonky 
	 * 00:00 => minutes:seconds
	 * 00    => seconds
	 * 00.0  => minutes.seconds
	 */
	workspace = [[[timer cell] stringValue] componentsSeparatedByString:@":"];
	/* workspace should be two items, minutes and seconds. */
	wait = [[workspace objectAtIndex:0] intValue];
	wait = wait * 60;
	wait += [[workspace objectAtIndex:1] intValue];


	NSLog([NSString stringWithFormat:@"Starting timer with %f", wait]);
	[spinner startAnimation:self ];
	newtimer = [[NSTimer scheduledTimerWithTimeInterval:wait
					target:self
					selector:@selector(teaIsReady:)
					userInfo:msg
					repeats:NO] retain];
	
	[self updateTimeList:[[timer cell] stringValue]];
}

- (void)teaIsReady:(NSTimer *)aTimer
{
	NSString *msg;
	NSUserDefaults *def;
	
	msg = [aTimer userInfo];
	def = [NSUserDefaults standardUserDefaults];
	
	/* show it to the user somehow. */
	NSLog(@"Completed timer");
	NSLog(msg);

	[spinner stopAnimation:self ];
	
	/* Bounce
	 */
	if( [def boolForKey:MCTTBounce] ) {
		[NSApp requestUserAttention:NSInformationalRequest];
	}
	
	/* Growl
	 http://growl.info/documentation/implementing-growl.php?lang=cocoa
	 */
	if( [def boolForKey:MCTTGrowl] ) {
		
		NSDictionary *userInfo = [NSDictionary dictionaryWithObjectsAndKeys:
			@"Timer Finished", GROWL_NOTIFICATION_NAME,
			@"Tadpol's Tea Timer", GROWL_APP_NAME,
			msg, GROWL_NOTIFICATION_TITLE,
			msg, GROWL_NOTIFICATION_DESCRIPTION,
			nil];
	
		[[NSDistributedNotificationCenter defaultCenter] 
			postNotificationName:GROWL_NOTIFICATION
			object:nil
			userInfo:userInfo];
	}
	
	/* Alert
	 */
	if( [def boolForKey:MCTTAlert] ) {
		NSAlert *al = [[NSAlert alloc] init];
		[al setAlertStyle:NSInformationalAlertStyle];
		[al setMessageText:msg];
		[al setInformativeText:msg];
		[al runModal];
	}	 

	[msg release];
}

// combobox displays a MRU of times.
- (void)updateTimeList:(NSString *)new
{
	int old, max;
	
	max = [tres count];
	
	old = [tres indexOfObject:new];
	if( old >= 0 && old < max ) {
		[tres removeObjectAtIndex:old];
	}else
	if( max > 5) { /* make that 5 a preference */
		[tres removeLastObject];
	}
	[tres insertObject:new atIndex:0];

	[[timer cell] reloadData];

	// save to defaults
	[[NSUserDefaults standardUserDefaults] setObject:[NSArray arrayWithArray:tres]
		forKey:MCTTTimeList];
}

// ==========================================================
// Combo box data source methods
//   this is to fill the drop down, and to autocompleting.
// ==========================================================

- (int)numberOfItemsInComboBox:(NSComboBox *)aComboBox {
    return [tres count];
}
- (id)comboBox:(NSComboBox *)aComboBox objectValueForItemAtIndex:(int)index {
	return [tres objectAtIndex:index];
}

- (unsigned int)comboBox:(NSComboBox *)aComboBox indexOfItemWithStringValue:(NSString *)string {
    return [tres indexOfObject:string];
}

- (NSString *) firstMatchingPrefix:(NSString *)prefix {
    NSString *string = nil;
    NSString *lowercasePrefix = [prefix lowercaseString];
    NSEnumerator *stringEnum = [tres objectEnumerator];
    while ((string = [stringEnum nextObject])) {
		if ([[string lowercaseString] hasPrefix: lowercasePrefix]) return string;
    }
    return nil;
}

- (NSString *)comboBox:(NSComboBox *)aComboBox completedString:(NSString *)inputString {
    NSString *candidate = [self firstMatchingPrefix: inputString];
    return (candidate ? candidate : inputString);
}

@end
