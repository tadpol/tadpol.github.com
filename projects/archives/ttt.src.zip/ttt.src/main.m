//
//  main.m
//  ttt
//
//  Created by Michael Conrad Tadpol Tilstra on Thu Oct 28 2004.
//  Copyright (c) 2004 __MyCompanyName__. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, const char *argv[])
{
    return NSApplicationMain(argc, argv);
}
