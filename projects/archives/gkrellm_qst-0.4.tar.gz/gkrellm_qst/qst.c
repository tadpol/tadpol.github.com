/* quakestat - you'll want atleast gkrellm 1.0.6
 * Copyright 2001 Michael Conrad Tilstra. aka Tadpol
 *                <tadpol@tadpol.org>
 *
 * This is free software released under the GNU General Public License.
 * There is no warranty for this software.  See the file COPYING for
 * details.
 *
 * FIXME If the update command runs while the server is absent, things
 * hang.  I'm not seeing this bug....
 *
 * TODO fix up the config interface to be usefriendly instead of fiendly.
 *
 * ToDDynho Changes is after line 132 , toddynho@www.com . 12/09/2002
 */
#include <stdio.h>
#include <strings.h>
#include <gkrellm/gkrellm.h>

#include "qsticon.xpm"

#define   CONFIG_NAME  "qst"  /* Name in the configuration window */
#define   STYLE_NAME   "qst"  /* Theme subdirectory name and gkrellmrc 
                               * style name.
                               */
/* VERSION is defined int he Makefile now.*/

/* some defines*/
#define MAX_MAP_NAME_LEN 64
#define NEW_MAP "Have not talked with quake server yet"

/* Pulled apart for abstraction purposes.  Of course, the way I did this
 * does nothing for anyone really.  But it helps me.  See in the future
 * there, there will be friendlier config interface that will adjust the
 * first set of defines.  And an advanced conf tab for the second set.
 * Which means the second set needs to get %s's or somesuch.
 */
#define QSTATCMD "qstat"
#define GAMETYPE "-q3s"
#define GAMEBIN  "quake3"
#define SERVERLOC "quake" /* server:port */
#define AWK      "awk"
#define XTERM    "xterm"
#define StatusChgCmd "echo \"We've got Quake!\""

#define QCMD   QSTATCMD " " GAMETYPE " " SERVERLOC " | " \
               AWK " '/^" SERVERLOC "/ {print $2 $3;}'"
#define SCMD   XTERM " -e " GAMEBIN " +connect " SERVERLOC " &"
#define TTCMD  QSTATCMD " -P " GAMETYPE " " SERVERLOC " | " \
               AWK " '/frags/'"
#define CHCMD  "ps ax | grep " GAMEBIN " | grep -v grep > /dev/null && "\
               StatusChgCmd 

static Panel   *panel;
static gint    style_id;
static Decal   *curmap;
static Decal   *plycnt;
static Decal   *qpic;

/* need to be able to find the configuable points. (there must be a better
 * way)
 */
static GtkWidget *qstatcmd;
static GtkWidget *qstartcmd;
static GtkWidget *tooltipcmd;
static GtkWidget *changecmd;
static GtkWidget *spn_freq;

/* some other things to track */
static gchar Mapname[MAX_MAP_NAME_LEN];
static gint  Player_cur=0, Player_max=0;
static gint  changed=FALSE;
static gchar tooltip_text[2048];
static GtkTooltips *tooltip_widg = NULL;

/* settings */
int check_freq = 5;
char *qcommand = NULL;
char *scommand = NULL;
char *ttcommand = NULL;
char *chcommand = NULL;

/* functions. */
void get_players(void)
{
   FILE *ff;
   char buffy[81];
   int tt_len=0;

   if( !(ff=popen(ttcommand, "r")) ) {
      strcpy(tooltip_text, "Error getting player list!!");
      return;
   }

   tooltip_text[0] = '\0'; /* "clear" the string */

   /* read pipe */
   while( fgets(buffy, 81, ff) ) {
      tt_len += strlen( buffy ) +1;
      if( tt_len >= 2048 ) break;
      strcat(tooltip_text, buffy);
   }

   pclose( ff );

   gtk_tooltips_set_tip(tooltip_widg, panel->drawing_area, tooltip_text, NULL);
}

void get_stats(void)
{
   FILE* ff;
   int ret=0;
   gint new_Pc, new_Pm;
   gchar new_mn[MAX_MAP_NAME_LEN],todd[10];

#ifdef DEBUG_PIPE
   fprintf(stderr, "Entering get_stats\n");
#endif

   if( !(ff=popen(qcommand, "r")) ) {
      strncpy( Mapname, "Error opening quakestat pipe!!", MAX_MAP_NAME_LEN);
      Player_cur = 0;
      Player_max = 0;
      changed = TRUE;
      return;
   }

#ifdef DEBUG_PIPE
   fprintf(stderr, "Opened pipe,\n");
#endif

   ret = fscanf( ff, "%d/%d %60s", &new_Pc, &new_Pm, new_mn );
   
	// by ToDDynho .. check if the server is not down... toddynho@www.com //
	
	fscanf( ff, "%60s", todd );

	if(!strcasecmp(todd,"DOWN")) { strcpy(new_mn,"DOWN"); new_Pc = 0; new_Pm = 0; }

	// end of my changes //
		
   pclose( ff );

   if( new_Pc != Player_cur || new_Pm != Player_max ||
         strncmp(new_mn, Mapname, MAX_MAP_NAME_LEN) != 0 ) {
      changed = TRUE;
   }
   Player_cur = new_Pc;
   Player_max = new_Pm;
   strncpy(Mapname, new_mn, MAX_MAP_NAME_LEN);

#ifdef DEBUG_PIPE
   fprintf(stderr, "ret = %d\n", ret);
   fprintf(stderr, "Got %d %d %s\n", Player_cur, Player_max, Mapname); 

   fprintf(stderr, "Exitting get_stats\n");
#endif
}

static gint button_clicks(GtkWidget *widget, GdkEventButton *ev)
{
	switch (ev->button)
	{
	case 1:
      get_stats();
      get_players();
		break;
	case 3:
      system(scommand);
		break;
	}
   return FALSE;
}

static void update_plugin()
{
   static gint freq=0, x_scroll, w;
   char tmp[20];

   if( GK.minute_tick ) {
      freq++;
      if( freq == check_freq ) {
         get_stats();
         get_players();
         freq=0;
      }
   }

   if(changed) {
      system(chcommand);/* execute changed command. */
      changed = FALSE;
   }
   
   if(w==0) w = gkrellm_chart_width();
   x_scroll = (x_scroll +1) % (2 * w);
   curmap->x_off = w - x_scroll;
   gkrellm_draw_decal_text( panel, curmap, Mapname, w - x_scroll);

   snprintf(tmp, 20, "P: %d / %d", Player_cur, Player_max);
   gkrellm_draw_decal_text( panel, plycnt, tmp, w - x_scroll);

   gkrellm_draw_layers( panel );
}

static gint panel_expose_event(GtkWidget *widget, GdkEventExpose *ev)
{
    gdk_draw_pixmap(widget->window,
            widget->style->fg_gc[GTK_WIDGET_STATE (widget)],
            panel->pixmap, ev->area.x, ev->area.y, ev->area.x, ev->area.y,
            ev->area.width, ev->area.height);
    return FALSE;
}

#ifndef MAX
#define MAX(a,b) ((a>b)?a:b)
#endif

static void create_plugin(GtkWidget *vbox, gint first_create)
{
   Style         *style;
   TextStyle   *ts;
   gint        x,y;
   static GdkPixmap   *pixmap=NULL;
   static GdkBitmap   *mask=NULL;
   static GdkImlibImage *qicon = NULL;

   if (first_create) {
      panel = gkrellm_panel_new0();
      get_stats();
   } else {
      gkrellm_destroy_decal_list(panel);
   }

   style = gkrellm_meter_style(style_id);
   ts = gkrellm_meter_alt_textstyle(style_id);
   panel->textstyle = ts;


   gkrellm_load_image("qsticon", qsticon_xpm, &qicon, STYLE_NAME);
   gkrellm_render_to_pixmap(qicon, &pixmap, &mask, 0, 0);

   qpic = gkrellm_create_decal_pixmap(panel, pixmap, mask, 1, style, 1, 1);

   x = qpic->x + qpic->w + 2;
#if 0
   y = (qpic->h - gdk_string_height(ts->font, "PR")) /2;
#endif
   plycnt = gkrellm_create_decal_text( panel, "PR0d freq", ts, style, x, 3, 0);

   y = MAX(plycnt->y + plycnt->h , qpic->y + qpic->h ) + 2;
   curmap = gkrellm_create_decal_text( panel, NEW_MAP, ts, style, 1, y, -1);


   gkrellm_configure_panel(panel, NULL, style);
   panel->label->h_panel += 2;
   gkrellm_create_panel(vbox, panel, gkrellm_bg_meter_image(style_id));
   gkrellm_monitor_height_adjust(panel->h);

   gkrellm_draw_decal_pixmap(panel, qpic, 0);

   if( tooltip_widg == NULL ) {
      tooltip_widg = gtk_tooltips_new();
      strcpy(tooltip_text, NEW_MAP);
      gtk_tooltips_set_tip(tooltip_widg, panel->drawing_area,
            tooltip_text, NULL);
      gtk_tooltips_set_delay(tooltip_widg, 750);
   }

   if (first_create) {
       gtk_signal_connect(GTK_OBJECT (panel->drawing_area), "expose_event",
               (GtkSignalFunc) panel_expose_event, NULL);
       gtk_signal_connect(GTK_OBJECT (panel->drawing_area),
             "button_press_event",
               (GtkSignalFunc) button_clicks, NULL);
   }
}

static void qst_create_tab(GtkWidget *tab_vbox)
{
    GtkWidget      *tabs;

    tabs = gtk_notebook_new();
    gtk_notebook_set_tab_pos(GTK_NOTEBOOK(tabs), GTK_POS_TOP);
    gtk_box_pack_start(GTK_BOX(tab_vbox), tabs, TRUE, TRUE, 0);
   
   {
      GtkWidget *tbl, *label, *lbl_qcmd, *lbl_scmd, *lbl_ttcmd, *lbl_chcmd;
      GtkWidget *lbl_freq, *box_freq;
      GtkObject *spn_freq_adj;

      tbl = gtk_table_new (8, 2, FALSE);
      gtk_container_set_border_width (GTK_CONTAINER (tbl), 10);
      gtk_table_set_row_spacings (GTK_TABLE (tbl), 10);
      gtk_table_set_col_spacings (GTK_TABLE (tbl), 10);

   /* quake stat command*/
      lbl_qcmd = gtk_label_new (_("Quakestat cmd:"));
      gtk_table_attach (GTK_TABLE (tbl), lbl_qcmd, 0, 1, 0, 1,
         (GtkAttachOptions) (GTK_FILL),
         (GtkAttachOptions) (GTK_EXPAND), 0, 0);
      gtk_label_set_justify (GTK_LABEL (lbl_qcmd), GTK_JUSTIFY_RIGHT);
      gtk_misc_set_alignment (GTK_MISC (lbl_qcmd), 1, 0.5);

      qstatcmd = gtk_entry_new_with_max_length (100);
      gtk_widget_set_name (qstatcmd, "qstatcmd");
      gtk_table_attach (GTK_TABLE (tbl), qstatcmd, 1, 2, 0, 1,
         (GtkAttachOptions) (GTK_EXPAND | GTK_FILL),
         (GtkAttachOptions) (0), 0, 0);
      gtk_entry_set_text (GTK_ENTRY (qstatcmd), qcommand );

   /* quake start command*/
      lbl_scmd = gtk_label_new (_("Quake start cmd:"));
      gtk_table_attach (GTK_TABLE (tbl), lbl_scmd, 0, 1, 2, 3,
         (GtkAttachOptions) (GTK_FILL),
         (GtkAttachOptions) (GTK_EXPAND), 0, 0);
      gtk_label_set_justify (GTK_LABEL (lbl_scmd), GTK_JUSTIFY_RIGHT);
      gtk_misc_set_alignment (GTK_MISC (lbl_scmd), 1, 0.5);

      qstartcmd = gtk_entry_new_with_max_length (100);
      gtk_widget_set_name (qstartcmd, "qstartcmd");
      gtk_table_attach (GTK_TABLE (tbl), qstartcmd, 1, 2, 2, 3,
         (GtkAttachOptions) (GTK_EXPAND | GTK_FILL),
         (GtkAttachOptions) (0), 0, 0);
      gtk_entry_set_text (GTK_ENTRY (qstartcmd), scommand );

   /* tool tip command*/
      lbl_ttcmd = gtk_label_new (_("Tool tip cmd:"));
      gtk_table_attach (GTK_TABLE (tbl), lbl_ttcmd, 0, 1, 4, 5,
         (GtkAttachOptions) (GTK_FILL),
         (GtkAttachOptions) (GTK_EXPAND), 0, 0);
      gtk_label_set_justify (GTK_LABEL (lbl_ttcmd), GTK_JUSTIFY_RIGHT);
      gtk_misc_set_alignment (GTK_MISC (lbl_ttcmd), 1, 0.5);

      tooltipcmd = gtk_entry_new_with_max_length (100);
      gtk_widget_set_name (tooltipcmd, "tooltipcmd");
      gtk_table_attach (GTK_TABLE (tbl), tooltipcmd, 1, 2, 4, 5,
         (GtkAttachOptions) (GTK_EXPAND | GTK_FILL),
         (GtkAttachOptions) (0), 0, 0);
      gtk_entry_set_text (GTK_ENTRY (tooltipcmd), ttcommand );

   /* change command*/
      lbl_chcmd = gtk_label_new (_("Change cmd:"));
      gtk_table_attach (GTK_TABLE (tbl), lbl_chcmd, 0, 1, 6, 7,
         (GtkAttachOptions) (GTK_FILL),
         (GtkAttachOptions) (GTK_EXPAND), 0, 0);
      gtk_label_set_justify (GTK_LABEL (lbl_chcmd), GTK_JUSTIFY_RIGHT);
      gtk_misc_set_alignment (GTK_MISC (lbl_chcmd), 1, 0.5);

      changecmd = gtk_entry_new_with_max_length (100);
      gtk_widget_set_name (changecmd, "changecmd");
      gtk_table_attach (GTK_TABLE (tbl), changecmd, 1, 2, 6, 7,
         (GtkAttachOptions) (GTK_EXPAND | GTK_FILL),
         (GtkAttachOptions) (0), 0, 0);
      gtk_entry_set_text (GTK_ENTRY (changecmd), chcommand );

   /* Update frequency */
      lbl_freq = gtk_label_new (_("Update freq(min):"));
      gtk_table_attach (GTK_TABLE (tbl), lbl_freq, 0, 1, 7, 8,
         (GtkAttachOptions) (GTK_FILL),
         (GtkAttachOptions) (GTK_EXPAND), 0, 0);
      gtk_label_set_justify (GTK_LABEL (lbl_freq), GTK_JUSTIFY_RIGHT);
      gtk_misc_set_alignment (GTK_MISC (lbl_freq), 1, 0.5);

      box_freq = gtk_hbox_new (FALSE, 0);
      gtk_table_attach (GTK_TABLE (tbl), box_freq, 1, 2, 7, 8,
         (GtkAttachOptions) (GTK_FILL),
         (GtkAttachOptions) (GTK_FILL), 0, 0);

      spn_freq_adj = gtk_adjustment_new (check_freq, 1, 15, 1, 1, 1);
      spn_freq = gtk_spin_button_new (GTK_ADJUSTMENT (spn_freq_adj), 1, 0);
      gtk_widget_set_name (spn_freq, "spn_freq");
      gtk_box_pack_start (GTK_BOX (box_freq), spn_freq, FALSE, TRUE, 0);
      gtk_spin_button_set_update_policy (GTK_SPIN_BUTTON (spn_freq),
         GTK_UPDATE_IF_VALID);
      gtk_spin_button_set_snap_to_ticks (GTK_SPIN_BUTTON (spn_freq), TRUE);
      gtk_spin_button_set_wrap (GTK_SPIN_BUTTON (spn_freq), TRUE);

   /*Now add it */
      label = gtk_label_new("Options");
      gtk_notebook_append_page(GTK_NOTEBOOK(tabs),tbl,label);
   }
   {
      GtkWidget *text, *label, *scroll;
      gchar *info_text[] = {
         "QST watches your favorite quake server, showing you ",
         "how many players are in the current map, and the name ",
         "of that map.\n",
         "Mouse button one will refresh the status immeadily, while ",
         "mouse button three will start quake.\n\n",
         "<b>Options:\n",
         "<b> Quakestat cmd:\n\t",
         "The command to run to get the current status ",
         "from the quake server. It expects the output of the status ",
         "gathering command to be: <",
         "<i>current_number_of_players",">/<",
         "<i>Max_number_of_players", "> <","<i>Map_Name>\n",
         "This is easily set using something like awk to filter the ",
         "output of whichever command you need to use.\n\n",
         "<b> Quake start cmd:\n\t",
         "how to start up a game of quake.\n\n",
         "<b> Tool tip command:\n\t",
         "What command to use to fill the tool tip.\n\n",
         "<b> Change command:\n\t",
         "What to execute when the map or the player count changes.  ",
         "Useful if you don't want to stare at gkrellm all day.",
         "You probably want to pick something safe because it will run ",
         "while you are playing quake.\n\n",
         "<b> Update freq(min):\n\t",
         "How often to automatically check the server.\n"
      }; /* XXX Be nice if I could drop the font size by a point or two. */

      scroll = gtk_scrolled_window_new (NULL, NULL);
      gtk_scrolled_window_set_policy (GTK_SCROLLED_WINDOW(scroll),
            GTK_POLICY_AUTOMATIC, GTK_POLICY_AUTOMATIC);

      text = gtk_text_new(NULL,NULL);
      gtk_text_set_word_wrap(GTK_TEXT(text), TRUE);
      gtk_text_set_line_wrap(GTK_TEXT(text), TRUE);
      gkrellm_add_info_text(text, info_text,
            sizeof(info_text) / sizeof(gchar *));
      gtk_text_set_editable (GTK_TEXT(text), FALSE);

      gtk_container_add(GTK_CONTAINER(scroll), text);

      label = gtk_label_new(_("Info"));
      gtk_notebook_append_page(GTK_NOTEBOOK(tabs),scroll,label);
   }
   {
       gchar *plugin_about_text;
       GtkWidget *label, *text;

       plugin_about_text = g_strdup_printf(
             "QST\n"
            "GKrellM Quakestats Plugin v"VERSION"\n\n"
            "Copyright (C) 2001 Michael Conrad Tilstra (Tadpol)\n"
            "tadpol@tadpol.org\n\n"
            "Released under the GNU Public Licence"
      );

       text = gtk_label_new(plugin_about_text);
       label = gtk_label_new("About");
       gtk_notebook_append_page(GTK_NOTEBOOK(tabs),text,label);
       g_free(plugin_about_text);
   }
}

static void apply_qst_cfg(void) {
   if(qcommand) free(qcommand);
   qcommand = strdup( gtk_entry_get_text( GTK_ENTRY(qstatcmd) ) );
   if(scommand) free(scommand);
   scommand = strdup( gtk_entry_get_text( GTK_ENTRY(qstartcmd) ) );
   if(ttcommand) free(ttcommand);
   ttcommand = strdup( gtk_entry_get_text( GTK_ENTRY(tooltipcmd) ) );
   if(chcommand) free(chcommand);
   chcommand = strdup( gtk_entry_get_text( GTK_ENTRY(changecmd) ) );
   check_freq = gtk_spin_button_get_value_as_int( GTK_SPIN_BUTTON(spn_freq) );
}

static void save_qst_cfg( FILE* f) {
   fprintf(f, "%s update_freq %d\n", STYLE_NAME, check_freq);
   fprintf(f, "%s statcmd %s\n", STYLE_NAME, qcommand);
   fprintf(f, "%s startcmd %s\n", STYLE_NAME, scommand);
   fprintf(f, "%s tooltipcmd %s\n", STYLE_NAME, ttcommand);
   fprintf(f, "%s changecmd %s\n", STYLE_NAME, chcommand);
}

static void load_qst_cfg( gchar *args )
{
   char *option, *value;

   option = strtok(args, " \t\n");
   if( strncmp(option, "update_freq", 11) == 0) {
      value = strtok(NULL, " \t\n");
      if(value)
         sscanf(value, "%d", &check_freq);
   }else
   if( strncmp(option, "statcmd", 7) == 0) {
      value = strtok(NULL, "\n");
      if(value) {
         if(qcommand) free(qcommand);
         qcommand = strdup(value);
      }
   }else
   if( strncmp(option, "startcmd", 8) == 0) {
      value = strtok(NULL, "\n");
      if(value) {
         if(scommand) free(scommand);
         scommand = strdup(value);
      }
   }else
   if( strncmp(option, "tooltipcmd", 10) == 0) {
      value = strtok(NULL, "\n");
      if(value) {
         if(ttcommand) free(ttcommand);
         ttcommand = strdup(value);
      }
   }else
   if( strncmp(option, "changecmd", 9) == 0) {
      value = strtok(NULL, "\n");
      if(value) {
         if(chcommand) free(chcommand);
         chcommand = strdup(value);
      }
   }
}

/* The monitor structure tells GKrellM how to call the plugin routines.
*/
static Monitor   plugin_mon   =
   {
   CONFIG_NAME,        /* Title for config clist.   */
   0,               /* Id,  0 if a plugin       */
   create_plugin,      /* The create function      */
   update_plugin,      /* The update function      */
   qst_create_tab,            /* The config tab create function   */
   apply_qst_cfg,            /* Apply the config function        */

   save_qst_cfg,            /* Save user config         */
   load_qst_cfg,            /* Load user config         */
   STYLE_NAME,            /* config keyword         */

   NULL,            /* Undefined 2   */
   NULL,            /* Undefined 1   */
   NULL,            /* private   */

   MON_MEM,         /* Insert plugin before this monitor         */

   NULL,            /* Handle if a plugin, filled in by GKrellM     */
   NULL            /* path if a plugin, filled in by GKrellM       */
   };


  /* All GKrellM plugins must have one global routine named init_plugin()
  |  which returns a pointer to a filled in monitor structure.
  */
Monitor *init_plugin()
   {
   /* If this next call is made, the background and krell images for this
   |  plugin can be custom themed by putting bg_meter.png or krell.png in the
   |  subdirectory STYLE_NAME of the theme directory.  Text colors (and
   |  other things) can also be specified for the plugin with gkrellmrc
   |  lines like:  StyleMeter  STYLE_NAME.textcolor orange black shadow
   |  If no custom theming has been done, then all above calls using
   |  style_id will be equivalent to style_id = DEFAULT_STYLE_ID.
   */
   style_id = gkrellm_add_meter_style(&plugin_mon, STYLE_NAME);

   if( qcommand == NULL ) {
      qcommand = strdup(QCMD);
   }
   if( scommand == NULL ) {
      scommand = strdup(SCMD);
   }
   if( ttcommand == NULL ) {
      ttcommand = strdup(TTCMD);
   }
   if( chcommand == NULL ) {
      chcommand = strdup(CHCMD);
   }

   return &plugin_mon;
   }

/* vim: ts=3:sw=3
 */
