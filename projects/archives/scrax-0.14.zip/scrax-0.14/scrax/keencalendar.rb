# Copyright 2005-2006, Michael Conrad Tadpol Tilstra <tadpol@tadpol.org>
# All rights reserved.
#
# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions
# are met:
#
# 1. Redistributions of source code must retain the above copyright
#    notice, this list of conditions, and the following disclaimer.
#
# 2. Redistributions in binary form must reproduce the above copyright
#    notice, this list of conditions, and the following disclaimer in the
#    documentation and/or other materials provided with the distribution.
#
# 3. The name of the author may not be used to endorse or promote products
#    derived from this software without specific prior written permission.
#
# THIS SOFTWARE IS PROVIDED BY THE AUTHOR "AS IS" AND ANY EXPRESS OR
# IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
# OF TITLE, NON-INFRINGEMENT, MERCHANTABILITY AND FITNESS FOR A PARTICULAR
# PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY
# DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
# (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
# LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
# AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR
# TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
# OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.    

require 'html/htmltokenizer'

module Scrax
    class Scrax
    # :stopdoc:
    
    	# Find the next balanaced close tag for an open tag.
    	# returns all unparsed text from current to close_tag
    	def matchCloseTag(toker, open_tag, close_tag)
    		wad=''
    		up=1
    		while token = toker.getNextToken
    			if token.kind_of? HTMLText
    				wad += token.to_s
    			elsif token.kind_of? HTMLTag
    				if token.tag_name == open_tag
    					up +=1
    				elsif token.tag_name == close_tag
    					up -= 1
    					return wad if up == 0
    				end
					wad += token.to_s
				end
    		end
    	end
    # :startdoc:
    	
        # Shortcut for #scan_for_keencalendars inside of #if_changed
        def calendarpage
        	if_changed {|data| replace []; self << scan_for_keencalendars(data) }
        end
        
        # This is a scrapper for pulling out the links found in the little calendars that comics on 
        # the Keen servers use.
        # 
        # This returns an array of Scrax::RssItem
        #
        # The debug flags that this scrapper can use:
        #
        # found_page:: For each URI that seems to be in a calendar, print what we found.
        # first_tds:: For each possible table that might be a calendar.
        # found_month:: For each table that is a month calendar.
        # found_day:: For each day that matches. Called same time as found_page, but
        #             reports different information.
        #--
        # I wonder if I should try rewriting this with hpricot, or just leave working things alone.
        def scan_for_keencalendars(data)
			months = %w{January February March April May June July August September October November December}
			months += %w{Jan Feb Mar Apr May Jun Jul Aug Sep Oct Nov Dec}
			monthspattern = months.sort.join('|')
        	rss = Array.new
			monyr = ''
			link = ''
			day = ''
			grab = false
			bd = @prefs['base'].chomp('/')
			tokenize = HTMLTokenizer.new(data)
			while tb = tokenize.getTag('table', '/table')
				if tb.tag_name == 'table'
					td = tokenize.getTag('td')
					dlog(:first_tds, "Found a td #{td.attr_hash.inspect}")
					if td.attr_hash['colspan'] == '7' or td.attr_hash['colspan'] == '8'
#                            monyr = tokenize.getTrimmedText('/td').gsub(/(\&\S*;)/, '')
						monyr = matchCloseTag(tokenize, 'td', '/td').gsub(/(\&[a-zA-Z]+;)/, ' ')
						if monyr.match(%r{(#{monthspattern})\s*(\d\d\d\d)}i)
							monyr = $1 + ' ' + $2
						end
						dlog(:found_month, "Found month table for #{monyr}")
						# parse out each day.
						while td = tokenize.getTag('td', '/table')
							break if td.tag_name == '/table'
							aa = tokenize.peekNextToken
							if aa.kind_of?(HTMLTag) and aa.tag_name == 'a'
								link = aa.attr_hash['href']
							end
							day = tokenize.getTrimmedText('/td').gsub(/(\&\S*;)/, '')
							
							if day =~ /\d+/
								# skip over couple of days from previous and next months.
								if day.to_i == 1
									if not grab
										grab = true
									else
										grab = false
									end
								end
								if grab and link.length > 0
									link = bd + link unless link[0,1] == 'h'
									#id = "%11u" % Time.parse("#{day} #{monyr}").to_i
									dlog(:found_day, "Found day: #{day}")
									dlog(:found_page, "Found Page URL: #{link}")
									rss << RSSItem.new("#{day} #{monyr}", link, Time.parse("#{day} #{monyr}"))
								end
							end
							link = day = ''
						end
					else
						# First td in table must have colspan of 7or8 to be what we want.
						next
					end
				end
			end # while tokenize table /table
			rss
        end
        
    end # class Scrax
end # module Scrax
