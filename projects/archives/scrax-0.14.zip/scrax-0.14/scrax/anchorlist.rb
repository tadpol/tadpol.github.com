# Copyright 2005-2006, Michael Conrad Tadpol Tilstra <tadpol@tadpol.org>
# All rights reserved.
#
# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions
# are met:
#
# 1. Redistributions of source code must retain the above copyright
#    notice, this list of conditions, and the following disclaimer.
#
# 2. Redistributions in binary form must reproduce the above copyright
#    notice, this list of conditions, and the following disclaimer in the
#    documentation and/or other materials provided with the distribution.
#
# 3. The name of the author may not be used to endorse or promote products
#    derived from this software without specific prior written permission.
#
# THIS SOFTWARE IS PROVIDED BY THE AUTHOR "AS IS" AND ANY EXPRESS OR
# IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
# OF TITLE, NON-INFRINGEMENT, MERCHANTABILITY AND FITNESS FOR A PARTICULAR
# PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY
# DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
# (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
# LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
# AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR
# TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
# OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.    

require 'html/htmltokenizer'

module Scrax
    class Scrax
    	# Shortcut for #scan_for_anchors inside of #if_changed
        def anchorlist(hrefpat, stoptag='/a')
        	if_changed {|data| replace []; self << scan_for_anchors(data, hrefpat, stoptag) }
        end
        
        # For pages that are lists of <a href=></a>
        # 
        # hrefpat:: A pattern that will match the contents of the href attribute
        #           within an anchor tag.
        # stoptag:: You can set a different tag to stop scanning title text from.
        #           Some pages will have interesting text following the </a>, so 
        #           this is a way to get that.  Careful not to grab too much though.
        #
        # The debug flags that this scrapper can use:
        #
        # found_page:: For each URI that matches hrefpat, print what we found.
        #--
        # Want to rebuild this with hpricot, and then see if I still need the stoptag.  I hope not.
        def scan_for_anchors(data, hrefpat, stoptag='/a')
        	rss = Array.new
			id = title = link = nil
			ptrn = Regexp.new(hrefpat) unless hrefpat.kind_of? Regexp
			tokenize = HTMLTokenizer.new(data)
			while anchr = tokenize.getTag('a')
				if anchr.attr_hash['href'] != nil and
				   anchr.attr_hash['href'] =~ ptrn
					title = tokenize.getTrimmedText(stoptag)
					link = @prefs['base'].to_s + anchr.attr_hash['href']
					dlog(:found_page, "Found Page URL: #{anchr.attr_hash['href']}")
					rss << build_item(title.strip, link)
				end
			end
			rss
        end
        
        
    end
end
