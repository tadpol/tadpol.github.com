# Copyright 2005-2006, Michael Conrad Tadpol Tilstra <tadpol@tadpol.org>
# All rights reserved.
#
# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions
# are met:
#
# 1. Redistributions of source code must retain the above copyright
#    notice, this list of conditions, and the following disclaimer.
#
# 2. Redistributions in binary form must reproduce the above copyright
#    notice, this list of conditions, and the following disclaimer in the
#    documentation and/or other materials provided with the distribution.
#
# 3. The name of the author may not be used to endorse or promote products
#    derived from this software without specific prior written permission.
#
# THIS SOFTWARE IS PROVIDED BY THE AUTHOR "AS IS" AND ANY EXPRESS OR
# IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
# OF TITLE, NON-INFRINGEMENT, MERCHANTABILITY AND FITNESS FOR A PARTICULAR
# PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY
# DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
# (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
# LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
# AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR
# TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
# OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.    

# :main:Scrax::Scrax
# :title:Scrax API Documentation
module Scrax
    # This is the main bit of Scrax.  Nearly all uses of this module will only
    # use this Class. 
    #
    # Most scrappers will look something like:
    #  sc = Scrax::Scrax.new('Scraper Title', 'http://somewhere')
    #  sc.anchorlist('/neatstuff/page(\d+).html')
    #  sc.limit(15)
    #  puts sc.to_rss
    # Though you can do fancier stuff, if you need:
    #  sc = Scrax::Scrax.new('Scraper Title', 'http://somewhere')
    #  sc.if_changed {|data| sc.replace []; sc << your_own_html_scrapings(data)}
    #  sc.limit(15)
    #  puts sc.to_rss
    #
    # The scan_for_* methods are just a bunch of very common patterns that get scraped off of web
    # pages.  Most are wrapped in other methods for even easier usage.
    #
    # If you need, you can temporarily set debug flags in the SCRAX_DEBUG environment
    # variable.
    class Scrax
        # Creates a new Scrax object.
        # title:: is the name of this feed.
        # uri:: is the link that is downloaded and parsed for RSSItem.
        # options:: is a set of key-values for extra stuff that you may want set.
        #
        # Some of the currently used key-values from options:
        # base:: a base ref.  The links found on many sites are relative links.
        #        But from a RSS feed, you need absolute links.  So this key provides
        #        a string to prefix onto the link of each RSSItem.
        # home:: The homepage.  Many times the page you scrape to build the RSS isn't
        #        the homepage of the site.  This lets you specify the link for generated
        #        feed. (base or uri are used if this is left out.)
        # date_pattern:: A DatePattern that describes what dates look like in the items of this 
        #                scrapping.
        # debug:: An array of flags that can be helpful when writing your own scrappers.
        #         These do various things, some print messages to stderr, some change the
        #         behavor of code paths.
        #
        # A useful debug flag that this uses is 'start_stop'.  This will print a message 
        # at the end of initialization of a Scrax object, and another message when it is 
        # released from memory.
        #--
        # The params to this needs some serious rethinking.
        def initialize(title, uri, options={})
            @prefs = Prefs.new(title)
            # A lot of hand waving follows.
            @prefs['base'] = uri unless @prefs.has_key? 'base'
            options.each { |k,v| @prefs[k] = v unless k == 'rss' }
            @prefs['title'] = title
            @prefs['uri'] = uri unless @prefs.has_key? 'uri'
            # this feels kludgy, but its what i want. is there better way?
            @prefs['home'] = options['base'] if not @prefs.has_key? 'home' and options.has_key? 'base'
            @prefs['home'] = uri unless @prefs.has_key? 'home'
            
            # must always have these.
            @prefs['rss'] = RSS.new(@prefs['title'], @prefs['home']) unless @prefs.has_key? 'rss'
            @prefs[:uris] = Hash.new unless @prefs.has_key? :uris

            if has_debug(:start_stop)
                ObjectSpace.define_finalizer(self, proc {|id| $stderr.puts "[#{Time.new}] Scrax Finished with #{title}"})
                $stderr.puts "[#{Time.new}] Scrax Starting on #{title}"
            end
        end
        
        # Access preference items. Good for any bit of data that you need to persist from one run
        # of your script to another.
        def [](k)
            @prefs[k]
        end
        # Access preference items. Good for any bit of data that you need to persist from one run
        # of your script to another.
        def []=(k,v)
            @prefs[k]=v
        end
        
        # Get the RSS feed that was built for this site as a string.
        def to_rss
            if @prefs['rss'].length == 0
                @prefs['rss'] << RSSItem.new('WARNING: No items parsed. Page may have changed layout, ' +
                                   'or Scraper maybe broken.', rand.to_s)
            end
            @prefs.save
            @prefs['rss'].to_s
        end
        
        # Replace the RSSItems to be the ones in the given array.
        def replace(items)
            @prefs['rss'].replace(items)
        end
        
        # Append RSSItems to the feed that you're building.  Will take either an array of RSSItems,
        # or a single RSSItem.
        #
        # Will also take a Hash with :title and :link keys.  Which it will convert into a RSSItem.
        #
        def append(items)
            if items.kind_of?(Array)
                @prefs['rss'].append(items)
            elsif items.kind_of?(RSSItem)
                @prefs['rss'] << items
            elsif items.kind_of?(Hash)
                raise "Bad shortcut hash, missing required :title key" unless items.has_key? :title
                raise "Bad shortcut hash, missing required :link key" unless items.has_key? :link
                @prefs['rss'] << build_item(items[:title], items[:link])
            else
                raise "Don't append classes of #{items.class} to a Scrax."
            end
        end
        alias :<< :append
                
        # Use the specified pattern to find a date in the string.
        #
        # pattern can be a Symbol of a predefined pattern, a new DatePattern, an Array, or nil
        #
        # If an Array, must be of either Symbols of predefined patterns, or new DatePatterns.
        # Each is tried in order, the first to match is used.
        #
        # If nil, each of the predefined patterns is tried until one works.
        #
        # The predefined patterns are:
        # :YYMMDD:: DatePattern.new(%r{(\d\d)\D?(\d\d)\D?(\d\d)}, :YMD)
        # :YYYYMMDD:: DatePattern.new(%r{(\d{4})\D?(\d\d)\D?(\d\d)}, :YMD)
        # :MMDDYY:: DatePattern.new(%r{(\d\d)\D?(\d\d)\D?(\d\d)}, :MDY)
        # :MMDDYYYY:: DatePattern.new(%r{(\d\d)\D?(\d\d)\D?(\d{4})}, :MDY)
        # :DDMMYY:: DatePattern.new(%r{(\d\d)\D?(\d\d)\D?(\d\d)}, :DMY)
        # :DDMMYYYY:: DatePattern.new(%r{(\d\d)\D?(\d\d)\D?(\d{4})}, :DMY)
        #
        def get_date(str, pattern)
            dp = { # converts key into year-month-day form.
                :YYMMDD => DatePattern.new(%r{(\d\d)\D?(\d\d)\D?(\d\d)}, :YMD),
                :YYYYMMDD => DatePattern.new(%r{(\d{4})\D?(\d\d)\D?(\d\d)}, :YMD),
                :MMDDYYYY => DatePattern.new(%r{(\d\d)\D?(\d\d)\D?(\d{4})}, :MDY),
                :MMDDYY => DatePattern.new(%r{(\d\d)\D?(\d\d)\D?(\d\d)}, :MDY),
                :DDMMYY => DatePattern.new(%r{(\d\d)\D?(\d\d)\D?(\d\d)}, :DMY),
                :DDMMYYYY => DatePattern.new(%r{(\d\d)\D?(\d\d)\D?(\d{4})}, :DMY)
                # ??? more predefined patterns???
            }
            
            if pattern.nil?
                patterns = [:YYYYMMDD, :MMDDYYYY, :MMDDYY, :YYMMDD, :DDMMYY, :DDMMYYYY].collect{|i| dp[i]}
            elsif pattern.kind_of? Symbol
                raise "Unknown predefined date pattern #{pattern}" unless dp.has_key? pattern
                patterns = [dp[pattern]]
            elsif pattern.kind_of? Array
                patterns = pattern.collect do|i|
                    if i.kind_of? DatePattern
                        i
                    elsif i.kind_of? Symbol
                        raise "Unknown predefined date pattern #{pattern}" unless dp.has_key? pattern
                        dp[i]
                    else
                        raise "Unknown in array to pattern of get_date"
                    end
                end
            elsif pattern.kind_of? DatePattern
                patterns = [pattern]
            end
            
            # scan for dates. first that works wins.
            patterns.each do |p|
                r = p.parse(str)
                return r unless r.nil?
            end
            nil
        end
        
        # Given a just a title and a link, try to get a good identifier out of it.
        #
        # A good identifier is preferably a date, or just some unique numbers.  If both those fail,
        # uses a bad identifier of Time.now (which is still better than nothing.)
        #
        # see #get_date
        def build_item(title, link)
            # look for dates, using suggested pattern, or trying all.
            date = get_date(title, @prefs['date_pattern'])
            date = get_date(link, @prefs['date_pattern']) if date.nil?
            # no dates? grab all numbers.
            date = link.scan(/\d+/).to_s.to_i if date.nil?
            date = title.scan(/\d+/).to_s.to_i if date.nil?
            # no numbers? use Time.now.
            date = Time.now if date.nil?
            RSSItem.new(title, link, date)
        end
        
        # Limits the number of RSSItem s.
        # This sorts the items first, and takes the largest items.
        def limit(n=20)
            @prefs['rss'].limit(n)
        end
        
        # Check to see if a given debug flag has been turned on.
        # flags:: Either a single flag, or an array of flags.  This is compared
        #         against @prefs[:debug], which is either a single flag or an
        #         array of flags.
        def has_debug(flags)
            return false unless @prefs.has_key? :debug
            @prefs[:debug] = [@prefs[:debug]] unless @prefs[:debug].class == Array
            flags = [flags] unless flags.class == Array
            return false if (@prefs[:debug] & flags).empty?
            true
        end
        
        # print debugging messages to stderr
        # flags:: Either a single flag, or an array of flags.  This is compared
        #         against @prefs[:debug], which is either a single flag or an
        #         array of flags.
        # message:: the message to display.
        def dlog(flags, message)
            return unless has_debug(flags)
            $stderr.puts "[#{Time.new}] #{message}"
        end
        
        # This method is deprecated.  Use #if_changed instead.
        #
        # This requires a block that takes two params. The first is a String of the downloaded page.
        # The second is a RSS object that you append new RSSItem to.  The block will *only*
        # get called if the page data has changed since the last time this was ran.
        #
        # The debug flags that this can use:
        #
        # reset_lastfetch:: refetch URI even if it hasn't changed.
        # page_updated:: Logs a message if the uri has changed.
        def blaze  # :yields: htmlpagedata, RSS
            if_changed do |data|
                rss = @prefs['rss']
                rss.clear
                begin
                    yield(data, rss)
                    # TODO somehow check parse results to see if the parser needs updating
                    # because the page changed too much.
                    #
                    # One way to do this might be to simply make sure that rss items were added.
                    if rss.length == 0
                        rss << RSSItem.new('WARNING: No items parsed. Page may have changed layout, ' +
                                           'or Scraper maybe broken.', rand.to_s)
                    end
                rescue
                    # we add a rss item here so that it gets seen. (since this is intended to
                    # be ran from say NetNewsWire, stderr won't usually get noticed.)
                    rss << RSSItem.new("ERROR: " + $!.to_s, rand.to_s)
                    $stderr.puts $!.to_s
                    $stderr.puts $!.backtrace
                end
                @prefs['rss'] = rss
            end
        end
        
        # Calls &block if the page data at uri has changed since the last time this was called.
        # 
        # The debug flags that this can use:
        #
        # reset_lastfetch:: refetch URI even if it hasn't changed.
        # page_updated:: Logs a message if the uri or chpt_uri has changed.
        def if_changed(uri=self['uri']) # :yields: html_page_data
            @prefs[:uris][uri] = Hash.new unless @prefs.has_key? uri
            @prefs[:uris][uri][:lastfetch] = nil if has_debug(:reset_lastfetch)
            @prefs[:uris][uri][:lastcheck] = Time.now
            lp = LatestPage.new(uri, @prefs[:uris][uri][:lastfetch])
            if lp.update
                dlog(:page_updated, "Page data at #{uri} has changed.")
                yield lp.data
                @prefs[:uris][uri][:lastfetch] = lp.lastfetch
                @prefs.save
            end
        end
        
        # If you parse a page for a changing uri, then follow that, after a while you will gather 
        # a great number of old uris in the preference data.  
        #
        # This is a function to drop uris that haven't been check in the last number of days.
        def remove_dino_uris(days=30)
            doom = Time.now - (days * 24 * 3600)
            @prefs[:uris].delete_if do |uri, info|
                info[:lastcheck] < doom
            end
        end

        # Shortcut for #scan_for_optionlist inside of #if_changed
        def optionlist
            if_changed {|data| replace []; self << scan_for_optionlist(data)}
        end
        
        # Pulls info out of an <select> list in a <form>.
        # currently rather gaks if there is more than one <select> list on the page.
        #
        # This is a very dumb scrapper.  It will most certainly break if there is more than one
        # option list in the page data.
        #
        # The debug flags that this scrapper can use:
        #
        # found_page:: For each option value, print what we found.
        def scan_for_optionlist(data)
            rss = Array.new
            data.scan(%r{option[^>]+value=["']([^'"]*)[^>]*>([^<]*)}i) do |value, text|
                text.gsub!(/<[^>]*>/, '')
                link = @prefs['base'].to_s + value.to_s
                if value.length > 0
                    dlog(:found_page, "Found Page URL: #{value.to_s}")
                    rss << build_item(text.strip, link)
                end
            end
            rss
        end
        
        
    end # class Scrax
    
    # Describe how to find a date within a string.
    #
    # This exists pretty much because Ruby doesn't support named back-references in Regexp.  Just 
    # needed a way to know which of the back-references in the Regexp were the year, month, and day.
    #
    # Q: Why not just pass things into Time.parse?
    # A: What is the day, month, and year of this string: "020103"
    class DatePattern
        # Create a new date pattern.
        # pattern:: A Regexp that matches just the date pattern you want with each part in groups.
        # modify:: Identify which groups from the pattern are the year, month, and day.
        #
        # Modify is one of :YMD, :MDY, :DMY, or :asis.  :asis takes the entire matched portion and 
        # passes it to Time.parse.  The others take the matched groups and pass to Time.local in 
        # the right ordering.
        def initialize(pattern, modify=:asis)
            @pattern = pattern
            @modify = modify
        end
        # Find and parse date from string into a Time
        def parse(string)
            md = string.match @pattern
            return nil if md.nil?
            case @modify
            when :asis
                Time.parse(md.to_s)
            when :YMD
                Time.local( md[1], md[2], md[3] )
            when :MDY
                Time.local( md[3], md[1], md[2] )
            when :DMY
                Time.local( md[3], md[2], md[1] )
            else
                raise "Unknown modify type in #{self.inspect}"
            end
        end
    end
    
end # module Scrax