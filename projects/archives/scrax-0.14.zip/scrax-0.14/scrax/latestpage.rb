# Copyright 2005, Michael Conrad Tadpol Tilstra <tadpol@tadpol.org>
# All rights reserved.
#
# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions
# are met:
#
# 1. Redistributions of source code must retain the above copyright
#    notice, this list of conditions, and the following disclaimer.
#
# 2. Redistributions in binary form must reproduce the above copyright
#    notice, this list of conditions, and the following disclaimer in the
#    documentation and/or other materials provided with the distribution.
#
# 3. The name of the author may not be used to endorse or promote products
#    derived from this software without specific prior written permission.
#
# THIS SOFTWARE IS PROVIDED BY THE AUTHOR "AS IS" AND ANY EXPRESS OR
# IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
# OF TITLE, NON-INFRINGEMENT, MERCHANTABILITY AND FITNESS FOR A PARTICULAR
# PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY
# DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
# (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
# LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
# AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR
# TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
# OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.    

require 'uri'
require 'net/http'
Net::HTTP.version_1_2
require 'time'

module Scrax

    # The lastest page data for an URI.
    #
    # Typically, you'll never use this class.
    class LatestPage
        # uri:: Which page to look at
        # lastfetch:: The time that we got it last
        def initialize(uri, lastfetch=nil)
            @uri = URI.parse(uri)
            begin
                if lastfetch.kind_of? Time
                    @lastfetch = lastfetch
                elsif lastfetch.kind_of? String
                    @lastfetch = Time.parse( lastfetch )
                elsif lastfetch == nil
                    @lastfetch = Time.gm('1990')
                end
            rescue
                # duno, fake it.
                @lastfetch = Time.gm('1990')
            end
            @data = nil
        end

        attr_reader :data, :lastfetch
                
        # Gets the latest copy.
        # Returns TRUE if we downloaded a new version.
        # Returns FALSE if the page hasn't changed yet.
        #  In many cases, if we cannot contact the page, we just assume unchanged.
        def update
            uri = @uri.dup
            headers = Hash.new
            headers['Host'] = uri.host.to_s # + ':' + uri.port.to_s
            headers['If-Modified-Since'] = @lastfetch.strftime('%a, %d %b %Y %H:%M:%S %Z')

			begin
                0.upto(10) do |retries|
					resp = Net::HTTP.start(uri.host, uri.port) do |http|
						http.get(uri.request_uri, headers)
					end
					case resp
						when Net::HTTPNotModified
							# nothing changed, nothing to save.
							return false
						when Net::HTTPSuccess
							@data = resp.body
							if resp.key? 'last-modified'
								@lastfetch = Time.parse(resp['last-modified'])
							else
								@lastfetch = Time.now
							end
							return true
						when Net::HTTPRedirection
							uri = URI.parse(resp['location'])
						when Net::HTTPNotFound
							$stderr.puts "[#{Time.new}] 404 @ #{uri.to_s}"
							return false
						#??? other error handling here???
					end
                end
                # too many redirections.
                return false
                
            rescue Timeout::Error => err
            	# print out a message for any one watching logs, and pretend
            	# there is no change.
            	$stderr.puts "[#{Time.new}] Timed out for #{@uri}"
            	return false
            end
        end

    end

end
