# Copyright 2005-2006, Michael Conrad Tadpol Tilstra <tadpol@tadpol.org>
# All rights reserved.
#
# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions
# are met:
#
# 1. Redistributions of source code must retain the above copyright
#    notice, this list of conditions, and the following disclaimer.
#
# 2. Redistributions in binary form must reproduce the above copyright
#    notice, this list of conditions, and the following disclaimer in the
#    documentation and/or other materials provided with the distribution.
#
# 3. The name of the author may not be used to endorse or promote products
#    derived from this software without specific prior written permission.
#
# THIS SOFTWARE IS PROVIDED BY THE AUTHOR "AS IS" AND ANY EXPRESS OR
# IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
# OF TITLE, NON-INFRINGEMENT, MERCHANTABILITY AND FITNESS FOR A PARTICULAR
# PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY
# DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
# (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
# LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
# AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR
# TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
# OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.    

require 'builder'
require 'uri'

module Scrax
    
    class RSSItem
        # Creates new item
        # title:: The title of this item
        # link:: The uri that this item points to
        # date:: When this item happened.  Can be a Time, String, Integer, or nil.
        #
        # Using a Time for date is preferred.  If a string, passed to Time.parse first.  If you 
        # cannot figure out the date for an item, but still have a unique numerical identifier, 
        # you can pass that in as an Integer.  If you have nothing, use nil.
        #
        # The date is converted into the item's id.  This is used for sorting, and with link used
        # to identify uniqueness. 
        #
        def initialize(title, link, date=nil)
            @title = title.to_s
            @link = link.to_s
            if date.nil?
                @date = Time.now
                @id = @date.to_i
            elsif date.kind_of? Integer
                @date = Time.now
                @id = date
            elsif date.kind_of? Time
                @date = date
                @id = @date.to_i
            elsif date.kind_of? String
                @date = Time.parse(date)
                @id = @date.to_i
            else
                raise "Unknown format for date parameter."
            end
        end
        attr_reader :id
                
        # build an identifier that is hopefully unique through space and time
        # for this feed.  This is modeled after an atom id, but since dates
        # for us might not be unique, but ids are.  And since ids are not always
        # dates, we have to fudge it a bit.
        def guid
            begin
                uri = URI.parse(@link.gsub(/#/, '/'))
                if @id == @date.to_i
                    ds = @date.strftime('%Y-%m-%d')
                else
                    ds = @id
                end
                "tag:#{uri.host},#{ds}:#{uri.path}#{uri.query}"
            rescue
                $stderr.puts $!.to_s
                $stderr.puts $!.backtrace
                @link
            end
        end
        
        # Returns a valid xml/rss snippet for this Item.
        def to_xml(xml=Builder::XmlMarkup.new(:indent=>2))
            xml.item do
                xml.comment! "id: #{@id.to_s}"
                xml.title @title
                xml.pubDate @date.rfc2822
                xml.link @link
                xml.guid self.guid, :isPermaLink=>false
            end
        end
        alias :to_s :to_xml
        
        def to_atom(xml=Builder::XmlMarkup.new(:indent=>2))
            xml.entry do
                xml.comment! "id: #{@id.to_s}"
                xml.title @title
                xml.link :href=>@link
                xml.id guid
                xml.published @date.xmlschema
            end
        end
        
        include Comparable
        def <=>(m)
            @id <=> m.id
        end
    end

    class RSS
        def initialize(title='', link='')
            @title = title.to_s
            @link = link.to_s
            @items = Array.new
        end
        
        def add(item)
            @items << item
        end
        alias :<< :add
        def set(idx, item)
            @items[idx] = item
        end
        def delete(item)
            @items.delete(item)
        end
        def clear
            @items.clear
        end
        def length
            @items.length
        end
        def append(ar)
            @items += (ar)
        end
        def replace(ar)
            @items.replace(ar)
        end
        # clips the list of items down to the last n of them.
        # Done by first sorting the list, then removing duplicates, then taking the 
        # 'n' items from the tail of the list.
        def limit(n)
            @items = @items.sort.uniq[ - n, n] if @items.length > n
        end
        
        # Returns a valid xml document as a string that is the rss feed for all items
        # in this RSS.
        def to_xml
            xml = Builder::XmlMarkup.new(:indent=>2)
            xml.instruct!
            xml.rss(:version=>'2.0') do
                xml.channel do
                    xml.title @title
                    xml.link @link
                    xml.generator 'Scrax'
                    
                    @items.each {|i| i.to_xml(xml)}
                end
            end
        end
        alias :to_s :to_xml
        
        def to_atom
            xml = Builder::XmlMarkup.new(:indent=>2)
            xml.instruct!
    		xml.feed('xmlns'=>'http://www.w3.org/2005/Atom') do
    		  xml.title @title
    		  xml.id @link
    		  xml.link :rel=>'alternate', :href=>@link
    		  xml.updated Time.now.xmlschema
    		  xml.generator %{Scrax}
    		  
    		  @items.each {|i| i.to_atom(xml) }
    		end
        end
#        alias :to_s :to_atom
    end
    
    

end
