# Copyright 2005-2006, Michael Conrad Tadpol Tilstra <tadpol@tadpol.org>
# All rights reserved.
#
# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions
# are met:
#
# 1. Redistributions of source code must retain the above copyright
#    notice, this list of conditions, and the following disclaimer.
#
# 2. Redistributions in binary form must reproduce the above copyright
#    notice, this list of conditions, and the following disclaimer in the
#    documentation and/or other materials provided with the distribution.
#
# 3. The name of the author may not be used to endorse or promote products
#    derived from this software without specific prior written permission.
#
# THIS SOFTWARE IS PROVIDED BY THE AUTHOR "AS IS" AND ANY EXPRESS OR
# IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
# OF TITLE, NON-INFRINGEMENT, MERCHANTABILITY AND FITNESS FOR A PARTICULAR
# PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY
# DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
# (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
# LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
# AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR
# TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
# OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.    

require 'html/htmltokenizer'

module Scrax
    class Scrax
        # For Archive pages that have a list of Chapter links.  These lead to 
        # another page which has the list of hrefs we are really after.
        #
        # This finds the 'most recent' chapter, then loads that. Since this 
        # scans nested pages, we cannot use the #blaze abstraction.
        #
        # chapter_pat:: A pattern that will match the contents of the href attribute
        #               within an anchor tag that points to the seperate chapter pages.
        # href_pat:: A pattern that will match the contents of the href attribute
        #            within an anchor tag that points to the artical pages.
        # stop_tag:: You can set a different tag to stop scanning title text from.
        #            Some pages will have interesting text following the </a>, so 
        #            this is a way to get that.  Careful not to grab too much though.
        #
        # This also uses a few additional options that can be set in the Scrax.new
        #
        # chpt_base:: Sepcifically for the chapter URIs parsed, prefix them with this. 
        # artc_base:: Sepcifically for the page URIs parsed from a chapter page, prefix them with this. 
        #             You can also set this to :chapter_dir, in which case it will use the dirname of
        #             the chapter URI as the base.
        #
        # The debug flags that this scrapper can use:
        #
        # reset_lastfetch:: refetch all URIs.
        # page_updated:: Logs a message if the uri or chpt_uri has changed.
        # found_chapter:: For each URI that matches chapter_pat, print what we found.
        # found_page:: For each URI that matches href_pat, print what we found.
        def chaptered_anchor_list(chapter_pat, href_pat, stop_tag='/a')
            if_changed(@prefs['uri']) do |data|
                # Chapter page changed, Need to find the lastest Chapter.
                base = @prefs['base']
                base = @prefs['chpt_base'] if @prefs.has_key? 'chpt_base'
                chapters = Array.new
                ptrn = Regexp.new(chapter_pat)
                tokenize = HTMLTokenizer.new(data)
                while anchr = tokenize.getTag('a')
                    if anchr.attr_hash['href'] != nil and
                       anchr.attr_hash['href'] =~ ptrn
                        id = anchr.attr_hash['href'].scan(/\d+/)[0]
                        chapters << [id, anchr.attr_hash['href'] ]
                        dlog(:found_chapter, "Found Chapter URL: #{anchr.attr_hash['href']}")
                    end
                end
                @prefs['chpt_uri'] = base.to_s + chapters.sort[-1][1]
            end
            
            # Ok, now we know what chapter page to be reading.
			if_changed(@prefs['chpt_uri']) do |data|
				@prefs['rss'].clear
            
                base = @prefs['base']
                base = @prefs['artc_base'] if @prefs.has_key? 'artc_base'
                base = File.dirname(@prefs['chpt_uri']) + '/' if base == :chapter_dir
                ptrn = Regexp.new(href_pat)
                tokenize = HTMLTokenizer.new(data)
                while anchr = tokenize.getTag('a')
                    if anchr.attr_hash['href'] != nil and
                       anchr.attr_hash['href'] =~ ptrn
                        title = tokenize.getTrimmedText(stop_tag)
                    	@prefs['rss'] << build_item(title.strip, base.to_s + anchr.attr_hash['href'])
                    	dlog(:found_page, "Found Page URL: #{anchr.attr_hash['href']}")
                    end
                end
            end
            
        end
        
    end
end
