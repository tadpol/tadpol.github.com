# Copyright 2005, Michael Conrad Tadpol Tilstra <tadpol@tadpol.org>
# All rights reserved.
#
# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions
# are met:
#
# 1. Redistributions of source code must retain the above copyright
#    notice, this list of conditions, and the following disclaimer.
#
# 2. Redistributions in binary form must reproduce the above copyright
#    notice, this list of conditions, and the following disclaimer in the
#    documentation and/or other materials provided with the distribution.
#
# 3. The name of the author may not be used to endorse or promote products
#    derived from this software without specific prior written permission.
#
# THIS SOFTWARE IS PROVIDED BY THE AUTHOR "AS IS" AND ANY EXPRESS OR
# IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
# OF TITLE, NON-INFRINGEMENT, MERCHANTABILITY AND FITNESS FOR A PARTICULAR
# PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY
# DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
# (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
# LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
# AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR
# TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
# OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.    

require 'yaml'

module Scrax
    # A Hash like class to save what we know.
    #
    # Typically, you'll never use this class.
    class Prefs
        def initialize(name)
            @key = name
            @items = Hash.new
            self.load
            if ENV.has_key? 'SCRAX_DEBUG'
            	tmp = ENV['SCRAX_DEBUG'].gsub(/:/,'').split(/[ ,]/)
            	tmp.delete_if {|i| i.length <= 0}
            	tmp.collect! {|i| i.intern }
            	@items[:debug] = tmp
            end
        end
        
        def set(key, val)
            @items[key] = val
        end
        alias :[]= :set
        
        def get(key)
            @items[key]
        end
        alias :[] :get
        
        def has_key?(key)
            @items.has_key? key
        end
        
        private
        # Gets us the path for the file we're saving our prefs in.
        # directories created if needed, but not file.
        def prefLoc
            # if the following exists, we're on a mac.
            psdir = "#{ENV['HOME']}/Library/Application Support"
            if File.exist?(psdir)
                psdir+='/Scrax/'
            else
                psdir="#{ENV['HOME']}/.Scrax/"
            end
            if not File.exists?(psdir)
                Dir.mkdir(psdir)
            end
            psdir + @key.gsub(/[^A-Za-z0-9]/,'')
        end
        
        public
        # recall what we've saved, if anything
        def load
            pf = prefLoc
            if File.exists? pf
                r = YAML::load(File.open(pf))
                if r.kind_of? Hash
                    @items = r
                end
            end
            nil
        end
        
        # Save what we know
        def save
        	@items.delete(:debug)
            pf = prefLoc
            File.open(pf, "w") do |file|
                file << @items.to_yaml
            end
            nil
        end
    end

end
