#!/usr/bin/env ruby
# Copyright 2006, Michael Conrad Tadpol Tilstra <tadpol@tadpol.org>
# All rights reserved.
# 
# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions
# are met:
# 
# 1. Redistributions of source code must retain the above copyright
#    notice, this list of conditions, and the following disclaimer.
# 
# 2. Redistributions in binary form must reproduce the above copyright
#    notice, this list of conditions, and the following disclaimer in the
#    documentation and/or other materials provided with the distribution.
# 
# 3. The name of the author may not be used to endorse or promote products
#    derived from this software without specific prior written permission.
# 
# THIS SOFTWARE IS PROVIDED BY THE AUTHOR "AS IS" AND ANY EXPRESS OR
# IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
# OF TITLE, NON-INFRINGEMENT, MERCHANTABILITY AND FITNESS FOR A PARTICULAR
# PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY
# DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
# (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
# LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
# AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR
# TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
# OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.    

require 'exifr'
require 'builder'
require 'getoptlong'

$directions = {'N' => 1, 'S' => -1, 'E' => 1, 'W' => -1}.freeze

$name = "foo"
$baseurl = "."
$description = ""
GetoptLong.new(
 ['--name', '-n', GetoptLong::REQUIRED_ARGUMENT],
 ['--description', '-d', GetoptLong::REQUIRED_ARGUMENT],
 ['--base', '-b', GetoptLong::REQUIRED_ARGUMENT],
 ['--help', '-h', GetoptLong::NO_ARGUMENT]
).each do |opt, arg|
    case opt
        when '--name'
            $name = arg
        when '--base'
            $baseurl = arg
        when '--description'
            $description = arg
        when '--help'
            puts %{photos2kml [options] jpegs > output.kml
 
Creates a placemark file based on the gps data in the EXIF info in JPEGs.
 
Options:
  --name, -n        Name of the folder that contains the placemarks
  --description, -d Description field for the folder
  --base, -b        base url for finding each jpeg.
  --help            This text.

Examples:
  photos2kml -n 'Local Example' -b `pwd` *.jgp > local.kml
  photos2kml -n 'Remote Example' -b 'http://server.com/yoursite/images/' *.jgp > remote.kml
}
            exit 0
    end
end

$baseurl += '/' unless $baseurl =~ %r{/$}

xml = Builder::XmlMarkup.new(:indent=>2)
xml.instruct!
xml.kml(:xmlns=>'http://earth.google.com/kml/2.0') do
    xml.Folder do
        xml.name $name
        xml.description $description
        
        ARGV.each do |img|
            ex = EXIFR::JPEG.new(img)
            next unless ex.exif?
            next unless ex.exif.has_key? :gps_longitude
            
            xml.Placemark do
                xml.name File.basename(img)
                xml.description %{<img src="#{$baseurl}#{img}" width="#{ex.width}" height="#{ex.height}" />}
                xml.Style do
                    xml.IconStyle do
                        xml.Icon do
                            xml.href $baseurl + img
                        end
                    end
                end
                deg, min, sec = ex.exif.gps_longitude
                long = (deg + min/60 + sec/3600).to_f * $directions[ex.exif.gps_longitude_ref]
                deg, min, sec = ex.exif.gps_latitude
                lat = (deg + min/60 + sec/3600).to_f * $directions[ex.exif.gps_latitude_ref]
                xml.Point do
                    xml.coordinates %{#{long},#{lat}}
                end
            end
        end #ARGV.each
        
    end
end

puts xml.target!
