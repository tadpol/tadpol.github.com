#!/usr/bin/env ruby
###############################################################################
# Copyright 2002-2003, Michael Conrad Tadpol Tilstra <tadpol@tadpol.org>
# All rights reserved.
# 
# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions
# are met:
# 
# 1. Redistributions of source code must retain the above copyright
#    notice, this list of conditions, and the following disclaimer.
# 
# 2. Redistributions in binary form must reproduce the above copyright
#    notice, this list of conditions, and the following disclaimer in the
#    documentation and/or other materials provided with the distribution.
# 
# 3. The name of the author may not be used to endorse or promote products
#    derived from this software without specific prior written permission.
# 
# THIS SOFTWARE IS PROVIDED BY THE AUTHOR "AS IS" AND ANY EXPRESS OR
# IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
# OF TITLE, NON-INFRINGEMENT, MERCHANTABILITY AND FITNESS FOR A PARTICULAR
# PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY
# DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
# (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
# LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
# AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR
# TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
# OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.    
###############################################################################
# This takes a single file source, and creates a bunch of files with
# tables that emulate a column browser format of that data.  This is
# mostly just for bookmark data.
# 
# The source file should be like:
# <bmk version="1">
# <list name="">
#     <link name="" href="" />
#     <list name="">
#         <link name="" href="" />
#     </list>
# </list>
# </bmk>
#
#
# I really should make a lot of this configurable via cmdline options
# or something.
#
# How this works is still a bit of twisted magicery.  I'd like to clean that
# up as well someday.

# REXML: http://www.germane-software.com/cgi-bin/software
require( "rexml/rexml" ) { |v| v >= "2.7" }
require "rexml/document"
require "rexml/parsers/sax2parser"
require "rexml/sax2listener"

class CVRoot
    def initialize
        @header = "<html>\n<body>"
        @footer = "</body>\n</html>"
# TODO: Should get a method of using files for the header and footer.
        @suffix = ".html"
        @prefix = "lk_"
        @children = Array.new
    end
    def append_child(c)
        @children << c
    end
    def write_cvn
        txt = @header + "\n<table class=\"bmk\">\n<tr><td>\n"
        txt += parent_text
        txt += "\n</td></tr>\n</table>\n" + @footer
        name = get_link()
        f = File.new(name, File::CREAT|File::TRUNC|File::WRONLY)
        f.write txt
        f.close
    end
    def build
        @children.each do |c|
            if(c.type.to_s == 'CVNode' )
                c.build
            end
        end
    end
end

class CVNode < CVRoot
    attr_reader :name
    def initialize(n,p=nil)
        super()
        if p.type.to_s == 'CVRoot'
            @parent = nil
        else
            @parent = p
        end
        @name = n
        @children = Array.new
        @suffix = ".html"
    end
    def append_child(s)
        @children << s
    end
    
    def text(linked="")
        txt = ""
        @children.each do |e|
            if e.type.to_s == 'String'
                txt += e
            elsif e.type.to_s == 'CVNode'
                if e.name == linked
                    txt += "<b>#{e.name}</b>&nbsp;&nbsp;==&gt;<br>\n"
                else
                    txt += "<a href=\""
                    txt += e.get_link
                    txt += "\">#{e.name}&nbsp;&nbsp;&gt;&gt;&gt;</a><br>\n"
                end
            end
        end
        return txt
    end
    
    def parent_text(nme="", sep="\n</td><td>\n")
        if( @parent != nil )
            return @parent.parent_text(@name) + sep + self.text(nme)
        else
            return self.text(nme)
        end
    end

    def get_path(s='-')
        if @parent != nil
            return @parent.get_path + s + @name
        else
            return @name
        end
    end
    
    #scrubs out any tags and enties. Course, you're in trouble if there is a name conflict.
    def get_link(s='-')
        lnk = @prefix + self.get_path(s) + @suffix
        return lnk.gsub(/(<.+>)/, '').gsub(/(\&\w+;)/,'').gsub(/\s/,'_')
    end
    
    def build
        self.write_cvn
        @children.each do |c|
            if(c.type.to_s == 'CVNode' )
                c.build
            end
        end
    end
end

class MyStreamListener
    include REXML::SAX2Listener

    def initialize
        @current = nil
        @parents = Array.new
    end
    
    def get_attr_by_name(attributes, name)
        attributes.each do |a|
            if a[0] == name
                return a[1]
            end
        end
        return "nil"
    end

    def start_element uri, localname, qname, attributes
        case localname
            when "bmk"
                # check version.
                version = self.get_attr_by_name(attributes, "version")
                if version.to_s != "1"
                    puts "Unsupported bmk file version #{version}."
                    exit 1
                end
                # Create root.
                @current = CVRoot.new
            when "list"
                name = self.get_attr_by_name(attributes, "name")
                @parents << @current
                @current = CVNode.new( name, @current )
            when "link"
                # get name and href or fail
                href = self.get_attr_by_name(attributes, "href")
                name = self.get_attr_by_name(attributes, "name")
                @current.append_child( "<a href=\"#{href}\">#{name}</a>" )
            when "weekset"
                #??  comming soon.
            when "daily"
                #?? 
                # <daily name="" href="" days="1234567" />
                # <daily name="" href="" days="mon,tue,wed,thr,fri,sat,sun" />
        end
        
    end
    def end_element uri, localname, qname
        case localname
            when "bmk"
                @current.build
            when "list"
                tmp = @current
                @current = @parents.pop
                @current.append_child(tmp)
            when "link"
                @current.append_child("<br>\n")
            when "weekset"
                #??
            when "daily"
                #??
        end
    end
    def characters text
        @current.append_child( text.strip )
    end
end

parser = REXML::Parsers::SAX2Parser.new( File.new( ARGV[0] ) )
parser.listen( MyStreamListener.new )
parser.parse

