#!/usr/bin/ruby

require 'scrax'

sc = Scrax::Scrax.new('Something Positive', 'http://www.somethingpositive.net/archive.shtml',
    'base' => 'http://www.somethingpositive.net/')
sc.anchorlist('sp\d+\.shtml', 'a')
sc.limit
puts sc.to_rss
