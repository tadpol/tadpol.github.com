#!/usr/bin/ruby

require 'scrax'

sc = Scrax::Scrax.new('Catharsis', 'http://www.catharsiscomic.com/',
    'base' => 'http://www.catharsiscomic.com/archive.php?strip=')
sc.optionlist
puts sc.to_rss
