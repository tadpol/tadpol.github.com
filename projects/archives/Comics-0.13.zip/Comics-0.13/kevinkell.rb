#!/usr/bin/ruby

require 'scrax'

sc = Scrax::Scrax.new('Kevin & Kell', 'http://www.herdthinners.com/reverse.phtml',
	'base'=>'')
sc.anchorlist('http://www.herdthinners.com/index.phtml\?current=\d+')
puts sc.to_rss
