#!/usr/bin/ruby

require 'scrax'

sc = Scrax::Scrax.new('Zap!', 'http://www.zapinspace.com/archive.html',
    'base' => 'http://www.zapinspace.com/' )
sc.calendarpage
sc.limit
puts sc.to_rss
