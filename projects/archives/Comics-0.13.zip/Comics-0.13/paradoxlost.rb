#!/usr/bin/ruby

require 'scrax'
require 'cgi'

sc = Scrax::Scrax.new('Paradox Lost', 'http://paradox-lost.com/scr/archive2.js')
#sc.optionlist
sc.blaze do |data, rss|
    id = Time.at(0)
    data.scan(%r{option[^>]+value=["']([^'"]*)[^>]*>([^<]*)}i) do |value, text|
        if value.length > 1
            if text =~ %r{(\d+)/(\d\d)/(\d\d)}
                id = Time.utc($3.to_i, $1.to_i, $2.to_i, 0, 0, 0, 0)
            end
            value = 'http://paradox-lost.com/' + value unless value =~ /^http/
            text = CGI.unescapeHTML(text.strip).gsub(/&nbsp;/,'')
            rss << Scrax::RSSItem.new(text.strip, value, :date=>id )
        end
    end
end
sc.limit
puts sc.to_rss
