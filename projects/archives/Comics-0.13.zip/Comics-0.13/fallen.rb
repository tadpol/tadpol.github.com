#!/usr/bin/ruby

require 'scrax'

sc = Scrax::Scrax.new('Fallen', 'http://www.fallencomic.com/fal-page.htm')
# page is just weird enough to need a custom blazer.
sc.blaze do |data, rss|
    part = ''
    chapter = ''
    chn = 0
    title = nil
    id = nil
    ptrn = Regexp.new('pages/part(%20)?[0-9]+/\S+.htm')
    tokenize = HTMLTokenizer.new(data)
    while anchr = tokenize.getTag('a')
        if anchr.attr_hash['href'] != nil and
           anchr.attr_hash['href'] =~ ptrn
            title = tokenize.getTrimmedText('/a').strip
            if title =~ /^Part/i
                part = title
                chn = 0
            end
            unless title =~ /\d/
                chapter = title
                chn += 1
            end
            id = "%d%02d%03d" % [part.scan(/\d+/)[0].to_i, chn, title.scan(/\d+/)[0].to_i]
            title = '' if title == part or title == chapter
            rss << Scrax::RSSItem.new("#{part} #{chapter} #{title}", 'http://www.fallencomic.com/' + anchr.attr_hash['href'], id.to_i)
        end
    end
end
sc.limit
puts sc.to_rss
