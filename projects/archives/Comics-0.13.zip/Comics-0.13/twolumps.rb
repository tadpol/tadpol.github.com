#!/usr/bin/ruby

require 'scrax'

sc = Scrax::Scrax.new('Two Lumps', 'http://www.twolumps.net/',
    'base' => 'http://www.twolumps.net')
sc.calendarpage
puts sc.to_rss
