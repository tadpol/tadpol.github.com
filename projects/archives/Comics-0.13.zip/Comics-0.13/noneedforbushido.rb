#!/usr/bin/ruby

require 'scrax'

sc = Scrax::Scrax.new('No Need for Bushido', 'http://www.noneedforbushido.com/archive.html',
    'base' => 'http://www.noneedforbushido.com/')
sc.anchorlist('comic\d+.html')
sc.limit
puts sc.to_rss
