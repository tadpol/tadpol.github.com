#!/usr/bin/ruby

require 'scrax'

sc = Scrax::Scrax.new('Freefall', 
    'http://freefall.purrsia.com/ffdex.htm',
    'base'=>'http://freefall.purrsia.com')
sc.anchorlist('/ff\d+/fv\d+.htm')
sc.limit
puts sc.to_rss
