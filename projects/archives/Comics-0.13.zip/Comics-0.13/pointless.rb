#!/usr/bin/ruby

require 'scrax'

sc = Scrax::Scrax.new('Pointless', 'http://www.pointlesscomic.com/')
sc.optionlist
sc.limit
puts sc.to_rss
