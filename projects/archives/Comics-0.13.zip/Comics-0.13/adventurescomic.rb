#!/usr/bin/ruby

require 'scrax'

sc = Scrax::Scrax.new('Adventures!', 'http://www.adventurers-comic.com/archives.html',
    'base' => 'http://www.adventurers-comic.com')
sc.calendarpage
puts sc.to_rss
