#!/usr/bin/ruby

require 'scrax'

sc = Scrax::Scrax.new('Frightmoore University', 'http://www.frightmooreuniversity.com/',
    'base' => 'http://www.frightmooreuniversity.com/?comicid=')
sc.optionlist
sc.limit
puts sc.to_rss
