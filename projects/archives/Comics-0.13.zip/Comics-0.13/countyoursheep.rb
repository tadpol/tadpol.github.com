#!/usr/bin/ruby

require 'scrax'

sc = Scrax::Scrax.new('Count Your Sheep', 'http://www.countyoursheep.com/')
sc.calendarpage
puts sc.to_rss
