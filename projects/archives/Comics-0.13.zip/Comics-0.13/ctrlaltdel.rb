#!/usr/bin/ruby

require 'scrax'

sc = Scrax::Scrax.new('Ctrl+Alt+Del', 'http://www.ctrlaltdel-online.com/?t=archives',
    'base' => 'http://www.ctrlaltdel-online.com/')
sc.optionlist
sc.limit
puts sc.to_rss
