#!/usr/bin/ruby

require 'scrax'

sc = Scrax::Scrax.new('El Goonish Shive', 'http://www.egscomics.com/' )
sc.calendarpage
sc.limit
puts sc.to_rss
