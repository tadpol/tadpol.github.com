#!/usr/bin/ruby

require 'scrax'

sc = Scrax::Scrax.new('Polymer City Chronicles', 'http://www.polymercitychronicles.com/archive_list.html',
    'base' => 'http://www.polymercitychronicles.com/')
sc.anchorlist('\./archive/\d+.html')
sc.limit
puts sc.to_rss
