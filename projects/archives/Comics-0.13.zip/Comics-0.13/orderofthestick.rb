#!/usr/bin/ruby

require 'scrax'

sc = Scrax::Scrax.new('The Order of the Stick', 'http://www.giantitp.com/cgi-bin/GiantITP/ootscript',
    'base' => 'http://www.giantitp.com/cgi-bin/GiantITP/ootscript?SK=',
    'home' => 'http://www.giantitp.com/cgi-bin/GiantITP/ootscript')
sc.optionlist
sc.limit
puts sc.to_rss
