#!/usr/bin/ruby

require 'scrax'

sc = Scrax::Scrax.new('Kagerou', 'http://www.electric-manga.com/archive.html',
	'chpt_base' => '',
    'artc_base' => :chapter_dir )
sc.chaptered_anchor_list('\d+/kageroumenu\.html', '\d+\.html')
sc.limit
puts sc.to_rss
