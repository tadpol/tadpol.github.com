#!/usr/bin/ruby

require 'scrax'

sc = Scrax::Scrax.new('The Wings of Change', 'http://wingsofchange.keenspace.com/',
    'base' => 'http://wingsofchange.keenspace.com')
sc.calendarpage
puts sc.to_rss
