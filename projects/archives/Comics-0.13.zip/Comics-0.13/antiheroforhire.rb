#!/usr/bin/ruby

require 'scrax'

sc = Scrax::Scrax.new('Antihero for Hire', 'http://www.antiheroforhire.com/archive.html',
    'base' => 'http://www.antiheroforhire.com')
sc.calendarpage
sc.limit
puts sc.to_rss
