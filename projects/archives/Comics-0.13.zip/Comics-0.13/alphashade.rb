#!/usr/bin/ruby

require 'scrax'

sc = Scrax::Scrax.new('Alpha Shade', 'http://www.alpha-shade.com/www/picPages/HPages.htm',
    'base' => 'http://www.alpha-shade.com/www/picPages/',
    'home' => 'http://www.alpha-shade.com/')
sc.optionlist
sc.limit
puts sc.to_rss
