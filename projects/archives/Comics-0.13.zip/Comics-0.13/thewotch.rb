#!/usr/bin/ruby

require 'scrax'

sc = Scrax::Scrax.new('The Wotch', 'http://thewotch.com/')
sc.blaze do |data, rss|
    title = ''
    link = ''
    id = ''
    tokenize = HTMLTokenizer.new(data)
    while map = tokenize.getTag('area')
        link = map.attr_hash['href']
        if link =~ /\?epDate=(\d\d\d\d)-(\d\d)-(\d\d)$/
            title = "#{$1}-#{$2}-#{$3}"
            rss << Scrax::RSSItem.new(title, link, :date=>title)
        end
    end
end
puts sc.to_rss
