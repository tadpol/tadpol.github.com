#!/usr/bin/ruby

require 'scrax'

sc = Scrax::Scrax.new('The Devils Panties', 'http://devilspanties.keenspot.com/')
sc.calendarpage
puts sc.to_rss
