#!/usr/bin/env ruby
# Copyright 2006, Michael Conrad Tadpol Tilstra <tadpol@tadpol.org>
# All rights reserved.
# 
# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions
# are met:
# 
# 1. Redistributions of source code must retain the above copyright
#    notice, this list of conditions, and the following disclaimer.
# 
# 2. Redistributions in binary form must reproduce the above copyright
#    notice, this list of conditions, and the following disclaimer in the
#    documentation and/or other materials provided with the distribution.
# 
# 3. The name of the author may not be used to endorse or promote products
#    derived from this software without specific prior written permission.
# 
# THIS SOFTWARE IS PROVIDED BY THE AUTHOR "AS IS" AND ANY EXPRESS OR
# IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
# OF TITLE, NON-INFRINGEMENT, MERCHANTABILITY AND FITNESS FOR A PARTICULAR
# PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY
# DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
# (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
# LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
# AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR
# TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
# OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.    

require 'getoptlong'

allheaders = false
ignoreextension = true
skipthese = Array.new
includethese = Array.new

GetoptLong.new(
 [ '--allheaders', '-a', GetoptLong::NO_ARGUMENT ],
 [ '--ignoreextension', '-i', GetoptLong::NO_ARGUMENT ],
 [ '--skip', '-s', GetoptLong::REQUIRED_ARGUMENT ],
 [ '--include', '-I', GetoptLong::REQUIRED_ARGUMENT ]
).each do |opt, arg|
 case opt
    when '--allheaders'
      allheaders = ! allheaders
    when '--ignoreextension'
      ignoreextension = ! ignoreextension
    when '--skip'
      skipthese << arg
    when '--include'
      includethese << arg
 end
end

if ARGV.empty?
  files = Dir['*.[ch]']
else
  files = ARGV
end
fne = if ignoreextension
  files.collect { |f| f.sub(/\..*$/, '') }.uniq
else
  files
end
fl = Array.new
fr = Array.new

files.each do |file|
  lines = IO.readlines(file)
  file.sub!(/\..*$/,'') if ignoreextension
  lines.collect! do |line|
  	next unless line =~ %r{#include\s+(["<])([^">]+)[>"]}
  	sysinc = $1
  	incfile = $2
  	incfile.sub!(/\..*$/,'') if ignoreextension
  	if skipthese.include? incfile
  	  nil
  	elsif includethese.include? incfile
  	  incfile
  	elsif sysinc == '<' and allheaders
  	  incfile
  	elsif sysinc == '"'
  	  incfile
  	else
  	  nil
  	end
  end
  lines.compact!
  lines.delete_if {|line| line == file }
  lines.each do |line|
  	if fne.include?(line)
	  	fl
  	else
  		fr
  	end << "#{file} -> #{line};"
  end
end
puts "digraph includes {"
puts "node [shape = circle];"
puts fl.uniq.join("\n")
puts "node [shape = box];"
puts fr.uniq.join("\n")
puts "}"
