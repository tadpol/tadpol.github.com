#include <OS.h>
#include "InterfaceKit.h"
#include "VisualizationPlugin.h"
#include "SerLCD.h"

class lcdstats : public VisualizationPlugin {
// >>-- Start of CL-Amp visualization plugin's virtual functions --------------
public:
   // No thread considerations
   lcdstats(struct PluginConstructorStruct *ConstrInfo);
   ~lcdstats() {}
   bool Init ();
   void Cleanup ();
   
   // Thread A
   bool About(bool Question);
   bool Prefs(bool Question);
   unsigned long GetFlags();
   
   // Thread B
   void SongInfo(const struct SongInfoStruct *info);
   bool Render(const struct VisAudioInfoStruct *Info);
// ---- End of CL-Amp visualization plugin's virtual functions --------------<<

private: //data store
   SerLCD *LCD;

   // cheep bad method of determining when new song starts.
   int svdLen;
 
   // title bounced data
   int titlepos;
   int titledir;
   bigtime_t titlelastmove;

   // state
   bool faded;
   int  fading;
   char lcd_pps;

   // progressbar
   int pg_majorpos;
   int pg_minorpos;

};
