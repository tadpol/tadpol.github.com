
#include "lcd_Prefs.h"
#include <PopUpMenu.h>
#include <MenuItem.h>
#include <SerialPort.h>
#include <Alert.h>
#include <Beep.h>
#include <String.h>
#include "TPreferences.h"


/******************************************************************************
 * LcdPrefs()
 * This be the prefs window. All the goodies are in the background.
 */
LcdPrefs::LcdPrefs(void)
   : BWindow(BRect(200,200,373,263), "LCDclamp Prefs", B_TITLED_WINDOW,
         B_NOT_ZOOMABLE|B_NOT_MINIMIZABLE|B_NOT_RESIZABLE)
{
   BRect vrct = Bounds();
   background=new lcdPbg(vrct);
   rgb_color kGray = {219,219,219,255};
   background->SetViewColor(kGray);
   AddChild(background);
}

LcdPrefs::~LcdPrefs(void) { }

bool LcdPrefs::QuitRequested(void) { return true; }

/******************************************************************************
 * lcdPbg()
 *  and
 * ~lcdPbg()
 *
 * exciting they are.
 */
lcdPbg::lcdPbg(BRect AFrame)
   :BView(AFrame,NULL,B_FOLLOW_ALL_SIDES,B_NAVIGABLE | B_WILL_DRAW)
{ }

lcdPbg::~lcdPbg(void)
{ }

/******************************************************************************
 * AttachedToWindow()
 *
 * Builds up the prefs window.  Not happy am I. must type out screen, or use
 * crummy interface tools.  (damnit. I like InterfaceElements. why can't
 * bresources work like mac resources?????)
 */
void lcdPbg::AttachedToWindow(void)
{
   BPopUpMenu *popMenu = new BPopUpMenu("popped");

   ScanSerialPorts(popMenu);

   SerPorts=new BMenuField(BRect(22,11,100,22), "SerPorts", "Serial Port:",
         popMenu, B_FOLLOW_LEFT|B_FOLLOW_TOP, B_NAVIGABLE|B_WILL_DRAW);
   SerPorts->SetDivider(60);
   AddChild(SerPorts);

   popMenu = new BPopUpMenu("sized");

   BMenuItem *mItem = new BMenuItem("4x16", new BMessage(lcdSizeChange));
   mItem->SetMarked(true);
   popMenu->AddItem(mItem);

   SerSize=new BMenuField(BRect(22,36,100,47), "lcdsize", "LCD Size:",
         popMenu, B_FOLLOW_LEFT|B_FOLLOW_TOP, B_NAVIGABLE|B_WILL_DRAW);
   SerSize->SetDivider(60);
   AddChild(SerSize);

   /* hack stuff in for different sized lcds...later*/
   BView::AttachedToWindow();
}

/******************************************************************************
 * ScanSerialPorts()
 * Gets all of the available serial ports, and puts them into the popupmenu.
 */
void lcdPbg::ScanSerialPorts(BPopUpMenu *pum)
{
   BSerialPort bsp;
   char devName[B_OS_NAME_LENGTH];
   BMenuItem *mItem;
   BMessage *bmsg;

   for(int32 n = bsp.CountDevices() -1; n >= 0; n--) {
      bsp.GetDeviceName(n,devName);

      bmsg = new BMessage(lcdPortChange);
      bmsg->AddString("port", devName);
      mItem = new BMenuItem(devName, bmsg );
      if(n == 0) mItem->SetMarked(true);
      mItem->SetTarget(this);
      pum->AddItem(mItem);

   }
}

/******************************************************************************
 * MessageReceived()
 */
void lcdPbg::MessageReceived(BMessage *message)
{
   switch(message->what)
   {
      case lcdSizeChange:
         /* Nop for now */
         break;
      case lcdPortChange:
         {
            TPreferences tPref("CL-Amp_VisPlugin_lcd.preferences");
            BString str("/dev/ports/");
            str += message->FindString("port");
            tPref.SetString("port", str.String() ); 
#if 0
            BAlert *Alrt = new BAlert("", str.String() ,
                  "kewl",NULL,NULL, B_WIDTH_FROM_LABEL);
            Alrt->Go();
#endif
         }
         break;
      default :
         BView::MessageReceived(message);
         break;
   }
}



