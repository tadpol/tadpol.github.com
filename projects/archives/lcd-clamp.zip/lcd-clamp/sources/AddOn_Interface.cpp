#include "lcdstats.h"

// Normally nothing should be done here!!

//****************************************

extern "C" _EXPORT VisualizationPlugin* NewPlugin(struct PluginConstructorStruct *ConstrInfo);

//****************************************

VisualizationPlugin* NewPlugin(struct PluginConstructorStruct *ConstrInfo)
{
	ConstrInfo->Version= CURRENT_VISUALIZATION_PLUGIN_VERSION;

	lcdstats* plugin= new lcdstats(ConstrInfo);
  	return plugin;
}
