#ifndef __WlcdPrefs_H__ 
#define __WlcdPrefs_H__ 
#include <View.h>
#include <Window.h>
#include <Application.h>
#include <MenuField.h>
#include <Rect.h>
#include <Button.h>
#define lcdSizeChange    11
#define lcdPortChange    12

class LcdPrefs: public BWindow
{
   private:
		BView *background;
	public: 
		LcdPrefs(void);
		~LcdPrefs(void);
		bool QuitRequested(void);
};

class lcdPbg: public BView
{
   private:
		BMenuField *SerPorts;
		BMenuField *SerSize;
      void ScanSerialPorts(BPopUpMenu *pum);

	public:
		lcdPbg(BRect AFrame);
		~lcdPbg(void);
		void MessageReceived(BMessage *message);
		void AttachedToWindow(void);
};
#endif
