#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <AppKit.h>
#include <InterfaceKit.h>
#include <Point.h>
#include "lcdstats.h"
#include "lcd_Prefs.h"
#include "TPreferences.h"

static int blankchar[8] = {0,0,0,0,0,0,0,0};

static int progresschars[5][8] = {
   {16, 16, 16, 16, 16, 16, 16, 16},
   {24, 24, 24, 24, 24, 24, 24, 24},
   {28, 28, 28, 28, 28, 28, 28, 28},
   {30, 30, 30, 30, 30, 30, 30, 30},
   {31, 31, 31, 31, 31, 31, 31, 31}
};

static int Xfade[5][8] = {
   {14, 27, 17, 27, 14, 14, 27, 17},
   {14, 14, 27, 17, 27, 14, 14, 27},
   {27, 14, 14, 27, 17, 27, 14, 14},
   {17, 27, 14, 14, 27, 17, 27, 14},
   {27, 17, 27, 14, 14, 27, 17, 27}
};

static int playpausestop[3][8] = {
   { 0,  8, 12, 14, 15, 14, 12,  8},
   { 0, 10, 10, 10, 10, 10, 10,  0},
   { 0, 14, 14, 14, 14, 14, 14,  0}
};

/* this may get moved and or replaced when I support multi-sized lcds */
static const int lcdwidth=16;

// The first string is intended to be a short label for the type of audio
//  this plugin handles
// The second string should give a more complete description of the plugin
lcdstats::lcdstats(struct PluginConstructorStruct *ConstrInfo)
   : VisualizationPlugin ("LCDclamp",
         "Put playback stats onto a serial LCD. (by Mike Tilstra)")
{
	LCD= NULL;
}

char * centerline(char *s, char *d, int w);

bool lcdstats::Init()
{
   /* Consider: getting tprefs to use the settings dir that clamp gives us */
   TPreferences tPref("CL-Amp_VisPlugin_lcd.preferences");
   const char *tmp;
   status_t err=B_OK;

	LCD = new SerLCD();
	if(LCD==NULL) return false;

   try {
      if( (tmp = tPref.FindString("port")) == NULL ) {
         tPref.SetString("port", "/dev/ports/serial1");
         if((err=LCD->lcdInit("/dev/ports/serial1"))<0) throw err;
      } else {
         if((err=LCD->lcdInit((char *)tmp))<0) throw err;
      }

      BPoint pnt;
      if( tPref.FindPoint("size", &pnt) == B_NAME_NOT_FOUND ) {
         tPref.SetPoint("size", BPoint(4,16));
         if((err=LCD->setSize(4,16))<0) throw err;
      } else {
         if((err=LCD->setSize((int)pnt.x,(int)pnt.y))<0) throw err;
      }

   } catch(status_t err) {
      BAlert *al= new BAlert("lcderror","Failed to init lcd panel.",
            "bummer.",NULL,NULL,B_WIDTH_AS_USUAL,B_STOP_ALERT);
      al->Go();
      return false;
   }

   // Show splash screen.
   //  this will need some kind of relook to get working with mutlisized. */
#if 0
	LCD->sendData("  Lcd plug-in   ",1);
	LCD->sendData("   for Cl-Amp   ",2);
	LCD->sendData("       By       ",3);
	LCD->sendData("  Mike Tilstra  ",4);
#endif
   char out[20]; // max known lcd width.
   centerline("Lcd plug-in", out, lcdwidth);
   LCD->sendData(out, 1);
   centerline("for Cl-Amp", out, lcdwidth);
   LCD->sendData(out, 2);
   centerline("By", out, lcdwidth);
   LCD->sendData(out, 3);
   centerline("Mike Tilstra", out, lcdwidth);
   LCD->sendData(out, 4);
	LCD->updateDisplay();

   titlepos=0;
   titledir=1;
   titlelastmove=0;
   faded = true;
   fading =0;
   lcd_pps = 3;
   pg_majorpos=0;
   pg_minorpos=0;


   LCD->charGen(3, blankchar );
	return (true);
}

void lcdstats::Cleanup()
{
	if (LCD) {
		delete LCD;
	}
}

unsigned long lcdstats::GetFlags()
{
	return 0;
}

bool lcdstats::About(bool Question)
{
	if (!Question) {
		BAlert *theAlert = new BAlert("",
				"LCDclamp\n"
				"Version 1\n\n"
				"Made by Mike Tilstra\n"
				"E-mail: tadpol@kagi.com\n"
				"Show various bits of playback info onto a 4x16 LCD display "
				"that you've attacthed to a serial port.\n"
				"(support for other sized displays coming soon.)\n\n",
				"kewlies", NULL, NULL, B_WIDTH_FROM_LABEL);
		BTextView *theText = theAlert->TextView();
		if(theText) {
			theText->SetStylable(true);
			theText->Select(0,8);	// Adjust this to the length of your header!
			BFont ourFont;

			theText->SetFontAndColor(be_bold_font);
			theText->GetFontAndColor(2, &ourFont, NULL);
			ourFont.SetSize(24);
			theText->SetFontAndColor(&ourFont);
		}
		theAlert->Go();
	}
	return (true);
}

bool lcdstats::Prefs(bool Question)
{
   if( !Question) {
      LcdPrefs *pWin = new LcdPrefs();
      pWin->Show();
   }
	return (true);
}

/*
struct SongInfoStruct {
// Current song info
	char Title[MAX_VISPLUG_TITLE_LEN];
	long CurrTime, TotTime; // milliSeconds!
	long Progress; // (Promille! => 0=start, and 1000=end of file)
	long Frequency, BitRate;
	short Volume, Speed, Panning; // Panning is not used in CL-Amp (at least, not yet!)
	bool Stereo;

// Play mode
	bool Playing, Paused; // Sound is coming when you have Playing and NOT Paused! (Playing && !Paused)
	bool Fading; // True when CL-Amp is fading or crossfading

// Special buffer status (e.g. streaming...)
	bool BufferOn, PreBuffering;
	long BufferVolume;

// Input plugin flags
	unsigned long Flags;

// Reference number (don't care about this one!)
	void *InternalReference;
};
 */
   // update stored data.
// TODO detect when in a new song, and do some kid of reseting.
//      Do I even need that? seems to work without.
void lcdstats::SongInfo(const struct SongInfoStruct *info)
{
   int len;
   char shown[20]; // since 16 is less than 20, it just works....
   bigtime_t now;

   if( info->Title == NULL) return;
   now = system_time();

   len = strlen(info->Title);
   // still possible problem if two tracks have equal len titles.
   if( len != svdLen) { svdLen = len; titlepos = 0;}
   if( len > lcdwidth ) {
      if( now >= titlelastmove + 400000 ) {
         titlelastmove = now;
         titlepos += titledir;
         if( titlepos+lcdwidth > len || titlepos < 0) {
            titledir *= -1;
            titlepos += titledir;
         }
      }
      strncpy( shown, info->Title + titlepos, lcdwidth);
   } else { //should only do this part when song changes.
      unsigned int ws = (lcdwidth - len) /2;
      if(ws>0)
         sprintf(shown, "%*s%*s%*s",ws," ",len,info->Title,(lcdwidth-(len+ws))," ");
      else
         sprintf(shown, "%*s", lcdwidth, info->Title);

      //reset bounce for next long one
      titlepos=0;
      titledir=1;
   }

	LCD->sendData(shown,1);

   {
      unsigned int hours, minutes, seconds;
      seconds = (info->CurrTime /  1000) % 60;
      minutes = (info->CurrTime / 60000) % 60;
      hours   = (info->CurrTime / 3600000);
      sprintf(shown, " %4u:%02u:%02u     ", hours, minutes, seconds);
      // need to think of a good way for this too.
      shown[13] = 2;
      LCD->sendData(shown,2);
   }
   
   //this only happen when state changes.
   if( info->Fading != faded) {
      faded = info->Fading;
      if( faded )
         memset(shown, 3,lcdwidth);
      else
         memset(shown, ' ',lcdwidth);
      LCD->sendData(shown,3);
   }

   if( faded ) {
      ++fading %=5;
      LCD->charGen(3, Xfade[fading] );
   }

   char pps=2;
   if( info->Playing && !info->Paused )     pps=0;
   else if( info->Playing && info->Paused ) pps=1;

   if( lcd_pps != pps ) {
      LCD->charGen(2, playpausestop[pps] );
      lcd_pps = pps;
   }

   
   int minorpos = info->Progress / 13;
   int majorpos = minorpos / 5;
   minorpos %= 5;

   if( pg_majorpos != majorpos || pg_minorpos != minorpos ) {
      pg_majorpos = majorpos;
      pg_minorpos = minorpos;
      memset(shown, ' ',lcdwidth);
      int i;
      for(i=0; i< majorpos; i++)
         shown[i] = 6;
      shown[i] = 1;
      LCD->sendData(shown, 4);
      LCD->charGen(1, progresschars[minorpos]);
#if 0
      LCD->sendChar(4, i, 6);
      LCD->charGen(1, progresschars[minorpos]);
      LCD->sendChar(4, i++, 1);
#endif
   }

	LCD->updateDisplay();
}


bool lcdstats::Render(const struct VisAudioInfoStruct *info)
{
	bool Ok= true;
	
	return (Ok); // returning false will cause CL-Amp to call Cleanup(), since something is wrong...
}

/******************************************************************************
 * centerline()
 * Nifty little sprintf stunt that centers some text on a line with spaces on
 * either side.
 * s: text to be centered
 * d: buffer that gets out put
 * w: width to center within.
 *
 * Returns d, for reasons I forget.
 *
 * WARNING: w MUST be >= the length of s.
 *          d MUST be big enough to hold s centered. (usually equal to w)
 * 
 * Typical use:
 *  char text[] = "This is a test";
 *  char out[30];
 *  centerline(text, out, 30);
 */
char * centerline(char *s, char *d, int w)
{
   int l, ws;
   l = strlen(s);
   ws = (w-l) /2;
   if(ws>0) sprintf(d, "%*s%*s%*s", ws, " ", l, s, (w-(l+ws)), " ");
   else sprintf(d, "%*s", w, s);
   return d;
}


