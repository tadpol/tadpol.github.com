#!/usr/bin/env ruby
# created by Michael Conrad Tadpol Tilstra <tadpol@tadpol.org>
# this script is public domain.

require 'rexml/document'
require 'tempfile'

batched = Tempfile.new('showcores')
batched.puts "bt\n"

outf = REXML::Document.new '<rss version="2.0"><channel></channel></rss>'
outf.elements['/rss/channel'].add_element('title').text = "Core Dumps"
outf.elements['/rss/channel'].add_element('generator').text = "showcores.rb"

Dir['/cores/core.*'].each do |cored|
	item = outf.elements['/rss/channel'].add_element('item')
	item.add_element('pubDate').text = File.stat(cored).mtime.to_s
	item.add_element('link').text = "file://#{cored}"
	if File.stat(cored).readable?
		temp = File.popen("gdb -c #{cored} -batch -x #{batched.path}").readlines
		item.add_element('title').text = temp[0].chomp
		desc = item.add_element('description')
		desc.text = temp.join('')
		
		file = %r{`(.*)'}.match(temp[0])[1]
		unless file.nil?
			file = File.basename(file)
			clgs = File.popen("mdfind \"kMDItemFSName == '#{file}.crash.log'\"").readlines
			
			if clgs.length > 0
				desc.add_text "\n\nFound Crash Logs:\n\n"
				desc.add_text clgs.join(' ')
			end
		end
		
	else
		item.add_element('title').text = "Unreadable core: #{cored}"
	end
end

outf.write($stdout, 0)
