#!/usr/bin/env ruby
###############################################################################
# Copyright 2002-2003, Michael Conrad Tilstra <tadpol@tadpol.org>
# All rights reserved.
# 
# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions
# are met:
# 
# 1. Redistributions of source code must retain the above copyright
#    notice, this list of conditions, and the following disclaimer.
# 
# 2. Redistributions in binary form must reproduce the above copyright
#    notice, this list of conditions, and the following disclaimer in the
#    documentation and/or other materials provided with the distribution.
# 
# 3. The name of the author may not be used to endorse or promote products
#    derived from this software without specific prior written permission.
# 
# THIS SOFTWARE IS PROVIDED BY THE AUTHOR "AS IS" AND ANY EXPRESS OR
# IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
# OF TITLE, NON-INFRINGEMENT, MERCHANTABILITY AND FITNESS FOR A PARTICULAR
# PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY
# DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
# (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
# LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
# AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR
# TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
# OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.    
###############################################################################
#
# Description:
# Move the current contents of the trash into a subfolder for this month.
# (skipping other such subfolders)  If there are more than six of these sub
# folders remove the oldest one.  (each Volume plus Home gets its own set of 6)
# Only works on the current users Trash.

###############################################################################
# Tweekables:

# what the prefix for each of the monthly stores is.  This does leave us to the
# possiblity of conflicts, but I'd rather keep things in the trash, and keep them
# visible to the user.
stor_prefix = 'trash-for-'

# How many months of stuff to keep.
oldies = 6

###############################################################################
# Don't mess with stuff below unless you figured out what is going on first.
now = Time.new
trashlist = Hash.new

#Where are the trash cans?
trashlist[File.basename(ENV['HOME'])] = ENV['HOME'] + '/.Trash/'
Dir["/Volumes/*/.Trashes/#{Process.uid}/"].each do |p|
    p =~ %r{/Volumes/([^/]+)/}
    trashlist[$1] = p
end

# Now for each of our trashes...
trashlist.each_pair do |vol_name, trashcan|
    #puts "Looking in trashcan: #{trashcan} on #{vol_name}"
    # where to drop files.
    curstor = "#{trashcan}#{stor_prefix}#{vol_name}-#{now.year.to_s}-#{now.month.to_s}"
    
    #if curstor doesn't exist, create
    system("mkdir", "-p", curstor)
    
    # get lists of items and storage folders.
    movelist = Array.new
    storlist = Array.new
    
    Dir.foreach(trashcan) do |file|
        if file =~ %r{^#{stor_prefix}}
            storlist.push( file )
        else
            if file !~ /^\./
                movelist.push( file )
            else
                # Is a dot file; needs special work.
                # other dot files i need to skip?
                if file != '.' &&
                   file != '..' &&
                   file != '.DS_Store'
                   movelist.push( file )
                end
            end
        end
    end
    
    # put new trash into this month's storage.
    movelist.each do |file|
        # if file/folder already exists, append digits.
        # should do a more maclike appending of 'copy ###' someday
        if( FileTest.exists?( curstor + '/' + file ) )
            i=0
            while FileTest.exists?( curstor + '/' + file + '_' + i.to_s )
                i = i +1
            end
            system("mv", trashcan + file, curstor + '/' + file + '_' + i.to_s )
        else
            system("mv", trashcan + file, curstor)
        end
    end
    
    # If there is a stor folder that is older than six months, rm -rf it.
    # sort the list by year and then month.  Then I can just clear out the
    # one[s] that are at the end of the list
    storlist.sort! do |a,b|
        a =~ %r{#{stor_prefix}#{vol_name}-(\d+)-(\d+)}
        a_mnth = $2.to_i
        a_year = $1.to_i
        b =~ %r{#{stor_prefix}#{vol_name}-(\d+)-(\d+)}
        b_mnth = $2.to_i
        b_year = $1.to_i
        if a_year == b_year
            a_mnth <=> b_mnth
        else
            a_year <=> b_year
        end
    end

    while storlist.length > oldies
        del = storlist.shift
        puts "Deleting #{del}"
        system('rm', '-rf', trashcan + del)
    end
end    
    
