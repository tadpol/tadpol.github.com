/*
Copyright 2000, Micheal Conrad Tilstra, Tadpol.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions, and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions, and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. The name of the author may not be used to endorse or promote products
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE AUTHOR "AS IS" AND ANY EXPRESS OR
IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
OF TITLE, NON-INFRINGEMENT, MERCHANTABILITY AND FITNESS FOR A PARTICULAR
PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY
DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR
TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.    

*/

#include <string.h>
#include <iostream.h>
#include <stdio.h>
#include <stdlib.h>
#include <SerialPort.h>
#include <fstream.h>
#include <OS.h>

#include "x10moused.h"
#include "mx_conf.h"

int find_x10_code(BSerialPort *port);

#if 0
void dump_buffer(void *buf, int len)
{
        int i;
        char *c = (char *)buf;

        for(i=0; i<len; i++) {
                if( i % 8 == 0 )
                        printf("\n%4u: ", i);
                printf("%2x ", c[i]);
        }
        printf("\n");
}       
#endif

int main(){
	char data[1];
	int code=0, lcode=0;
   mx_modes mode = mx_mode_cd;
   bigtime_t ltime=0, ctime=0;
	
   mx_map map;
   hard_load(map);
   
	BSerialPort *port;
	
	port = new BSerialPort;
	port->SetFlowControl(0);
	port->SetDataBits(B_DATA_BITS_7);
	port->SetStopBits(B_STOP_BITS_1);
	port->SetDataRate(B_1200_BPS);
	port->SetParityMode(B_NO_PARITY);
	port->SetBlocking(true);
	port->SetTimeout(B_INFINITE_TIMEOUT);
	
	port->Open("serial1");
	//port->SetDTR(true);
	//port->SetRTS(true);
	//port->Write(&on,1);
	
	port->ClearInput();

   //swallow that freek byte.
   port->Read(data,1);
   
	while(1){	
      code = find_x10_code(port);
      ctime = system_time();
      if( code != X10_VOLUP && code != X10_VOLDOWN &&
            code == lcode && (ctime - ltime) < 200000 ) ;
      else
      switch (code) {
         case X10_POWER: printf("x10 power\n"); break;
         case X10_CHANUP: printf("x10 chan up\n"); break;
         case X10_CHANDOWN: printf("x10 chan down\n"); break;
         case X10_MUTE: printf("x10 mute\n"); break;
         case X10_ONE: printf("x10 one\n"); break;
         case X10_TWO: printf("x10 two\n"); break;
         case X10_THREE: printf("x10 three\n"); break;
         case X10_FOUR: printf("x10 four\n"); break;
         case X10_FIVE: printf("x10 five\n"); break;
         case X10_SIX: printf("x10 six\n"); break;
         case X10_SEVEN: printf("x10 seven\n"); break;
         case X10_EIGHT: printf("x10 eight\n"); break;
         case X10_NINE: printf("x10 nine\n"); break;
         case X10_ZERO: printf("x10 zero\n"); break;
         case X10_SHIFT: printf("x10 shift\n"); break;
         case X10_ENTER: printf("x10 enter\n"); break;
         case X10_AxB: printf("x10 a*b\n"); break;
         case X10_DISP: printf("x10 disp\n"); break;
         case X10_LAST: printf("x10 last\n"); break;
         case X10_REC: printf("x10 rec\n"); break;
         case X10_SELECT: printf("x10 select\n"); break;
         case X10_GUIDE:  printf("x10 guide\n"); break;

         case X10_PAUSE:
            // Need to make sure an action exists before we try to execute
            // it.
            system( map[mode][mx_btn_pause].action.data() );
            break;
         case X10_VOLUP:
            system( map[mode][mx_btn_vol_up].action.data() );
            break;
         case X10_VOLDOWN:
            system( map[mode][mx_btn_vol_down].action.data() );
            break;
         case X10_PLAY:
            system( map[mode][mx_btn_play].action.data() );
            break;
         case X10_STOP:
            system( map[mode][mx_btn_stop].action.data() );
            break;
         case X10_REW:
            system( map[mode][mx_btn_rew].action.data() );
            break;
         case X10_FF:
            system( map[mode][mx_btn_ff].action.data() );
            break;

         case X10_PHONE: mode = mx_mode_phone; break;
         case X10_CD: mode = mx_mode_cd; break;
         case X10_WEB: mode = mx_mode_web; break;
         case X10_DVD: mode = mx_mode_dvd; break;
         case X10_PC: mode = mx_mode_pc; break;
      }
      lcode = code;
      ltime = ctime;
	}

}

int find_x10_code(BSerialPort *port) {
   int n;
   char byte;
   for(;;) {
      n = port->Read(&byte, 1);

      switch(byte) {
         case 0x44:
            n = port->Read(&byte,1);
            switch(byte) {
               case 0x0F:
                  n = port->Read(&byte,1);
                  if( byte == 0x3f ) return X10_POWER;
                  break;
               case 0x2B:
                  n = port->Read(&byte,1);
                  if( byte == 0x3f ) return X10_PC;
                  break;
               case 0x06:
                  n = port->Read(&byte,1);
                  if( byte == 0x3f ) return X10_VOLUP;
                  break;
               case 0x07:
                  n = port->Read(&byte,1);
                  if( byte == 0x3f ) return X10_VOLDOWN;
                  break;
               case 0x02:
                  n = port->Read(&byte,1);
                  if( byte == 0x3f ) return X10_CHANUP;
                  break;
               case 0x03:
                  n = port->Read(&byte,1);
                  if( byte == 0x3f ) return X10_CHANDOWN;
                  break;
               case 0x05:
                  n = port->Read(&byte,1);
                  if( byte == 0x3f ) return X10_MUTE;
                  break;
               case 0x0D:
                  n = port->Read(&byte,1);
                  if( byte == 0x3f ) return X10_PLAY;
                  break;
               case 0x0E:
                  n = port->Read(&byte,1);
                  if( byte == 0x3f ) return X10_STOP;
                  break;
               case 0x1C:
                  n = port->Read(&byte,1);
                  if( byte == 0x3f ) return X10_REW;
                  break;
               case 0x1D:
                  n = port->Read(&byte,1);
                  if( byte == 0x3f ) return X10_FF;
                  break;
               default:
                  printf(" Unrecognised byte 0x44 0x%x, lvl 2\n",byte);
            }
            break;
         case 0x45:
            n = port->Read(&byte,1);
            switch(byte) {
               case 0x0B:
                  n = port->Read(&byte,1);
                  if( byte == 0x3f ) return X10_PHONE;
                  break;
               case 0x01:
                  n = port->Read(&byte,1);
                  if( byte == 0x3f ) return X10_ONE;
                  break;
               case 0x02:
                  n = port->Read(&byte,1);
                  if( byte == 0x3f ) return X10_TWO;
                  break;
               case 0x3:
                  n = port->Read(&byte,1);
                  if( byte == 0x3f ) return X10_THREE;
                  break;
               case 0x4:
                  n = port->Read(&byte,1);
                  if( byte == 0x3f ) return X10_FOUR;
                  break;
               case 0x5:
                  n = port->Read(&byte,1);
                  if( byte == 0x3f ) return X10_FIVE;
                  break;
               case 0x06:
                  n = port->Read(&byte,1);
                  if( byte == 0x3f ) return X10_SIX;
                  break;
               case 0x07:
                  n = port->Read(&byte,1);
                  if( byte == 0x3f ) return X10_SEVEN;
                  break;
               case 0x08:
                  n = port->Read(&byte,1);
                  if( byte == 0x3f ) return X10_EIGHT;
                  break;
               case 0x09:
                  n = port->Read(&byte,1);
                  if( byte == 0x3f ) return X10_NINE;
                  break;
               case 0x00:
                  n = port->Read(&byte,1);
                  if( byte == 0x3f ) return X10_ZERO;
                  break;
               case 0x2B:
                  n = port->Read(&byte,1);
                  if( byte == 0x3f ) return X10_SHIFT;
                  break;
               case 0x0A:
                  n = port->Read(&byte,1);
                  if( byte == 0x3f ) return X10_ENTER;
                  break;
               case 0x1D:
                  n = port->Read(&byte,1);
                  if( byte == 0x3f ) return X10_AxB;
                  break;
               case 0x1C:
                  n = port->Read(&byte,1);
                  if( byte == 0x3f ) return X10_DISP;
                  break;
               case 0x0E:
                  n = port->Read(&byte,1);
                  if( byte == 0x3f ) return X10_PAUSE;
                  break;
               case 0x0F:
                  n = port->Read(&byte,1);
                  if( byte == 0x3f ) return X10_LAST;
                  break;
               case 0x2d:
                  n = port->Read(&byte,1);
                  if( byte == 0x3f ) return X10_GUIDE;
                  break;
               default:
                  printf(" Unrecognised byte 0x45 0x%x, lvl 2\n",byte);
            }
            break;
         case 0x46:
            n = port->Read(&byte,1);
            switch(byte) {
               case 0x2B:
                  n = port->Read(&byte,1);
                  if( byte == 0x3f ) return X10_CD;
                  break;
               case 0x0B:
                  n = port->Read(&byte,1);
                  if( byte == 0x3f ) return X10_WEB;
                  break;
               case 0x13:
                  n = port->Read(&byte,1);
                  if( byte == 0x3f ) return X10_SELECT;
                  break;
               default:
                  printf(" Unrecognised byte 0x46 0x%x, lvl 2\n",byte);
            }
            break;
         case 0x47:
            n = port->Read(&byte,1);
            switch(byte) {
               case 0x0B:
                  n = port->Read(&byte,1);
                  if( byte == 0x3f ) return X10_DVD;
                  break;
               case 0x3F:
                  n = port->Read(&byte,1);
                  if( byte == 0x3f ) return X10_REC;
                  break;
               default:
                  printf(" Unrecognised byte 0x47 0x%x, lvl 2\n",byte);
            }
            break;
     // Best way to do buttons? i duno, probably not.
     // may perhaps should just always shove mouse stuff as mouse.
         case 0x50:
            n = port->Read(&byte, 1);
            switch(byte) {
               case 0x00:
                  n = port->Read(&byte, 1);
                  if( byte == 0x00 )
                     printf(" right mouse down\n");
                  break;
               default:
                  printf(" Unrecognised byte 0x50 0x%x, lvl 2\n",byte);
            }
            break;
         case 0x60:
            n = port->Read(&byte, 1);
            switch(byte) {
               case 0x00:
                  n = port->Read(&byte, 1);
                  if( byte == 0x00 )
                     printf("  left mouse down\n");
                  break;
               default:
                  printf(" Unrecognised byte 0x60 0x%x, lvl 2\n",byte);
            }
            break;
         case 0x40:
            n = port->Read(&byte, 1);
            switch(byte) {
               case 0x00:
                  n = port->Read(&byte, 1);
                  if( byte == 0x00 )
                     printf("       mouse up\n");
                  break;
               default:
               //   printf(" Unrecognised byte 0x40 0x%x, lvl 2\n",byte);
               {
                  char two;
                  n = port->Read(&two, 1);
                  printf("  mouse action 0x40 %x %x\n", byte, two);
               }
            }
            break;
         case 0x4c:
         case 0x43:
         case 0x4f:
            {
               char two[2];
               n = port->Read(&two[0], 1);
               n = port->Read(&two[1], 1);
               printf("  mouse action 0x%x %x %x\n", byte, two[0], two[1]);
            }
            break;
         default:
            printf(" Unrecognised byte 0x%x, lvl 1\n",byte);
      }
   }
}

