/*
Copyright 2000, Micheal Conrad Tilstra, Tadpol.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions, and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions, and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. The name of the author may not be used to endorse or promote products
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE AUTHOR "AS IS" AND ANY EXPRESS OR
IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
OF TITLE, NON-INFRINGEMENT, MERCHANTABILITY AND FITNESS FOR A PARTICULAR
PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY
DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR
TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.    

*/

#ifndef __mx_conf_h__
#define __mx_conf_h__

#include <SupportDefs.h>
#include <stl.h>
#include <string>

typedef enum { mx_act_shell, mx_act_bogus } action_type;

struct mx_action {
   action_type atype;
   string action;

   mx_action() : atype(mx_act_bogus), action("") {}
   mx_action(action_type t, string s) : atype(t), action(s) {}

   mx_action& operator= (const mx_action& e)
      {atype = e.atype; action = e.action; }

   bool operator== (const mx_action& e) const
      {return atype == e.atype && action == e.action;}
   bool operator< (const mx_action& e) const
      {return atype < e.atype && action < e.action;}
   friend ostream& operator<< (ostream& s, const mx_action& e) {
      if( e.atype == mx_act_shell ) s<< "shell\t";
      if( e.atype == mx_act_bogus ) s<< "bogus\t";
      return s << e.action;
   }
};

typedef enum {
   mx_mode_pc,
   mx_mode_cd,
   mx_mode_web,
   mx_mode_dvd,
   mx_mode_phone
} mx_modes;

typedef enum {
   mx_btn_power,
   mx_btn_vol_up,
   mx_btn_vol_down,
   mx_btn_chan_up,
   mx_btn_chan_down,
   mx_btn_mute,
   mx_btn_play,
   mx_btn_stop,
   mx_btn_rew,
   mx_btn_ff,
   mx_btn_one,
   mx_btn_two,
   mx_btn_three,
   mx_btn_four,
   mx_btn_five,
   mx_btn_six,
   mx_btn_seven,
   mx_btn_eight,
   mx_btn_nine,
   mx_btn_zero,
   mx_btn_shift,
   mx_btn_enter,
   mx_btn_axb,
   mx_btn_disp,
   mx_btn_pause,
   mx_btn_last,
   mx_btn_guide,
   mx_btn_select,
   mx_btn_rec
} mx_buttons;

typedef map<mx_buttons, mx_action> mx_btn_map;
typedef map<mx_modes, mx_btn_map> mx_map;


void hard_load(mx_map& m);
#endif /*__mx_conf_h__*/
