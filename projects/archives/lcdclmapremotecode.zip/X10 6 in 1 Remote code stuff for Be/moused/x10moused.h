/*
Copyright 2000, Micheal Conrad Tilstra, Tadpol.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions, and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions, and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. The name of the author may not be used to endorse or promote products
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE AUTHOR "AS IS" AND ANY EXPRESS OR
IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
OF TITLE, NON-INFRINGEMENT, MERCHANTABILITY AND FITNESS FOR A PARTICULAR
PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY
DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR
TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.    

*/
#ifndef __x10moused_h__
#define __x10moused_h__

#define X10_POWER    0x440F
#define X10_PC       0x442B
#define X10_VOLUP    0x4406
#define X10_VOLDOWN  0x4407
#define X10_CHANUP   0x4402
#define X10_CHANDOWN 0x4403
#define X10_MUTE     0x4405
#define X10_PLAY     0x440D
#define X10_STOP     0x440E
#define X10_REW      0x441C
#define X10_FF       0x441D
#define X10_PHONE    0x450B
#define X10_ONE      0x4501
#define X10_TWO      0x4502
#define X10_THREE    0x4503
#define X10_FOUR     0x4504
#define X10_FIVE     0x4505
#define X10_SIX      0x4506
#define X10_SEVEN    0x4507
#define X10_EIGHT    0x4508
#define X10_NINE     0x4509
#define X10_ZERO     0x4500
#define X10_SHIFT    0x452B
#define X10_ENTER    0x450A
#define X10_AxB      0x451D
#define X10_DISP     0x451C
#define X10_PAUSE    0x450E
#define X10_LAST     0x450F
#define X10_GUIDE    0x452D
#define X10_CD       0x462B
#define X10_WEB      0x460B
#define X10_SELECT   0x4613
#define X10_DVD      0x470B
#define X10_REC      0x473F

#endif /*__x10moused_h__*/
