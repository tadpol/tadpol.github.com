/*
Copyright 2000, Micheal Conrad Tilstra, Tadpol.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions, and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions, and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. The name of the author may not be used to endorse or promote products
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE AUTHOR "AS IS" AND ANY EXPRESS OR
IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
OF TITLE, NON-INFRINGEMENT, MERCHANTABILITY AND FITNESS FOR A PARTICULAR
PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY
DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR
TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.    

*/

#include "mx_conf.h"
#include <iostream.h>
#include <fstream.h>
#include <strstream.h>

/******************************************************************************
 * load_from_file()
 * We use this to load the conf file into memory.  This is temporary code.
 * I'll come up with a gui for setting these values later, and probably use
 * a different file format. (though if I get these functions down good, I
 * just may use them. on the otherhand, if I can make the mx_action
 * structure BFlattenable, then that TPreferences thing could be quite wiz.)
 */
#if 0
int load_from_file(char *fnme, mx_act_map& map)
{
   ifstream fin;
   char line[1024];
   string name, type, action;

   fin.open(fnme, ios::in | ios::nocreate);
   if( !fin ) {
      cerr << "Couldn't open \"" << fnme << "\" for reading"<< endl;
      return -1;
   }
   while( fin.getline( line, 1024) ) {
      if( line[0] == '#' || line[0] == '\0' ) continue;

      istrstream sin(line, 1024);
      sin >> name;
      sin >> type;
      //cout <<"pos is " << sin.tellg() << endl;
      // unset ios::skipws.... nope, wrong result.
      //sin.unsetf(ios::skipws);
      sin >> action; // this fucker needs the rest of the line.

      //cout << "==" << name << "==" << type << "==" << action << "==\n";

      if( type == "shell" ) 
         map[name] = mx_action(mx_act_shell, action);
   }

}
#endif

#if 0
void dump_out(mx_map& m)
{
   for(mx_map::const_iterator j = m.begin(); j != m.end(); ++j) {
      cout << (*j).first << endl;
      for(mx_btn_map::const_iterator i = j.begin(); i != j.end(); ++i) {
           cout << "\t" << (*i).first << "\t" << (*i).second << endl;
       }
   }
}
#endif

// hard load.
void hard_load(mx_map& m)
{
   mx_btn_map btnm;

   btnm[mx_btn_ff] = mx_action(mx_act_shell, "clr next fade");
   btnm[mx_btn_rew] = mx_action(mx_act_shell, "clr prev fade");
   btnm[mx_btn_play] = mx_action(mx_act_shell, "clr play fade");
   btnm[mx_btn_stop] = mx_action(mx_act_shell, "clr stop fade");
   btnm[mx_btn_pause] = mx_action(mx_act_shell, "clr pause");
   btnm[mx_btn_vol_up] = mx_action(mx_act_shell, "clr ivolume 2");
   btnm[mx_btn_vol_down] = mx_action(mx_act_shell, "clr dvolume 2");
   
   m[mx_mode_cd] = btnm;
}
