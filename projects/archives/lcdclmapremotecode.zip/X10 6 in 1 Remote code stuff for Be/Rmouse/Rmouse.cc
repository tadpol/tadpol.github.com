/*
Copyright 2000, Micheal Conrad Tilstra, Tadpol.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions, and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions, and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. The name of the author may not be used to endorse or promote products
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE AUTHOR "AS IS" AND ANY EXPRESS OR
IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
OF TITLE, NON-INFRINGEMENT, MERCHANTABILITY AND FITNESS FOR A PARTICULAR
PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY
DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR
TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.    

*/
/* the code */
#include <syslog.h>
#if 0
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#endif

#include <OS.h>
#include <InterfaceDefs.h>
#include <add-ons/input_server/InputServerDevice.h>
#include <SupportDefs.h>
#include <SerialPort.h>
#include <View.h>
#if 0
#include <storage/Path.h>
#include <FindDirectory.h>
#include <interface/Screen.h>
#include <Message.h>
#include <Debug.h>
#include <InterfaceDefs.h>
#endif

#include "Rmouse.h"

/******************************************************************************
 * Generate the object. 
 */
extern "C" _EXPORT BInputServerDevice* instantiate_input_device();

class __declspec (dllexport) BInputServerDevice;

BInputServerDevice* instantiate_input_device()
{
   return (new Rmouse());
}

/******************************************************************************
 * Rmouse()
 * Initialize the object
 */
Rmouse::Rmouse() : BInputServerDevice()
{
   static input_device_ref mover = { "Rmouse", B_POINTING_DEVICE, NULL };
   static input_device_ref *device[2] = { &mover, NULL };

   ::strcpy( rSerialPort, "/dev/ports/serial1" );
   rThrdWorking = true;

   RegisterDevices( device );
}


/******************************************************************************
 * Start()
 * get going.
 */
status_t Rmouse::Start( const char *device, void *)
{
   rThrd = ::spawn_thread( UserThread, device, B_REAL_TIME_DISPLAY_PRIORITY, this );
   ::resume_thread( rThrd );

   return B_NO_ERROR;
}

/******************************************************************************
 * Stop()
 * all done.
 */
status_t Rmouse::Stop( const char* , void *)
{
   status_t err = B_OK;

   rThrdWorking = false;
   ::wait_for_thread( rThrd, &err );
   rThrd = -1;

   return err;
}

/******************************************************************************
 * UserThread()
 * This does teh work while this addon is loaded.
 */
int32 Rmouse::UserThread(void *arg)
{
   Rmouse *dev = (Rmouse*)arg;
   BSerialPort *port;

   /*** setup ***/
   port = new BSerialPort;
   port->SetFlowControl(0);
   port->SetDataBits(B_DATA_BITS_7);
   port->SetStopBits(B_STOP_BITS_1);
   port->SetDataRate(B_1200_BPS);
   port->SetParityMode(B_NO_PARITY);
   /* these two may change... */
   port->SetBlocking(true);
   port->SetTimeout(B_INFINITE_TIMEOUT);

   if( port->Open( dev->rSerialPort ) <= 0) {
      ::syslog( LOG_USER, "Rmouse: cannot open serial port \'%s\'",
            dev->rSerialPort);
      dev->rThrdWorking = false;
      return B_OK;
   }

   port->ClearInput();

   char data[3];
   /* eat freek byte */
   port->Read(data, 1);

   int sigcnt=0;
   uint bytecnt=0;
   char inbyte;
   /*** main loop ***/
   while( dev->rThrdWorking )
   {
      int32 mbtn=0,what=0;
      int dx, dy;

      int32 len = port->Read( &inbyte, 1 );
      if( len < 0) continue;/*errr, error stuff. sometime soon, i hope */

      if( (inbyte & 64) == 64 ) bytecnt = 0;
      data[bytecnt] = inbyte;
 
      if( bytecnt == 3 ) {
         bytecnt = 0;
         /* remote button */
#if 0 /* if not an x10 btn, returns with a false, so things just continue as 
         normal */
         if( data[0] >= 0x44 && data[0] <= 0x47 && data[2] == 0x3f )
#endif
         if( dev->do_remote_button(data) ) continue;

         /* must be a regular mouse acting then. */
         if( data[0] == 0x50 && data[1] == 0 && data[2] == 0) {
            /*right down*/
            if(++sigcnt >= 3) {
               what = B_MOUSE_DOWN;
               mbtn |= B_SECONDARY_MOUSE_BUTTON;
               sigcnt=0;
            }
         } else if( data[0] == 0x60 && data[1] == 0 && data[2] == 0) {
            /*left down*/
            if(++sigcnt >= 3) {
               what = B_MOUSE_DOWN;
               mbtn |= B_SECONDARY_MOUSE_BUTTON;
               sigcnt=0;
            }
         } else if( data[0] == 0x40 && data[1] == 0 && data[2] == 0) {
            /*up*/
            if(++sigcnt >= 3) {
               what = B_MOUSE_UP;
               mbtn = 0;
               sigcnt=0;
            }
         }

         dx = ((data[0] & 3) << 6) + data[1];
         dy = ((data[0] & 12) <<4) + data[2];
         mbtn |= ((data[0] & 32)!=0)?B_PRIMARY_MOUSE_BUTTON:0;
         mbtn |= ((data[0] & 16)!=0)?B_SECONDARY_MOUSE_BUTTON:0;

         dev->sendMouseMessage( B_MOUSE_MOVED, mbtn, dx, dy );

      } /* if bytecnt == 3 */

   }

   /*** end ***/
   dev->rThrdWorking = false;
   delete port;

   return B_OK;
}

/******************************************************************************
 * sendMouseMessage()
 * this is called whe we've figured out some of the details of the normal
 * mouse action, and are attempting to make them visible to others.
 */
status_t Rmouse::sendMouseMessage( int32 what, int32 btn, int x, int y )
{
   BMessage *event = new BMessage( what );
   bigtime_t click_speed, now_system_time;
   int32 mouse_speed;

   get_click_speed( &click_speed );
   now_system_time = system_time();
   
   if( what == B_MOUSE_DOWN ) {
      if( rLastClickTime + click_speed <= now_system_time )
         rLastClickCount = 1;
      else
         ++rLastClickCount;
      rLastClickTime = now_system_time;
      event->AddInt32( "clicks", rLastClickCount);
   }

   get_mouse_speed(&mouse_speed);

   if( what == B_MOUSE_DOWN || B_MOUSE_UP )
      event->AddInt32( "modifiers", ::modifiers() );
   event->AddInt64( "when", system_time() );
   event->AddInt32( "buttons", btn );
   event->AddInt32( "x", (int32)(x * mouse_speed) );
   event->AddInt32( "y", (int32)(y * mouse_speed) );

   EnqueueMessage( event );

   return B_OK;
}

/******************************************************************************
 * do_remote_button()
 * gets called when we've determined that a button on the remote was pushed.
 *
 * I should add stuff to absorb the typical doubling of messages.
 */
bool Rmouse::do_remote_button( char *data )
{
   rmouse_buttons btn = rmouse_btn_null;

   if( data[2] != 0x3f ) return false;

   /* decode data field and figure out button action. */
   switch(data[0]) {
      case 0x44:
         switch(data[1]) {
            case 0x0F: btn = rmouse_btn_power; break;
            case 0x2B: rLastMode = rmouse_mode_pc; break;
            case 0x06: btn = rmouse_btn_vol_up; break;
            case 0x07: btn = rmouse_btn_vol_down; break;
            case 0x02: btn = rmouse_btn_chan_up; break;
            case 0x03: btn = rmouse_btn_chan_down; break;
            case 0x05: btn = rmouse_btn_mute; break;
            case 0x0D: btn = rmouse_btn_play; break;
            case 0x0E: btn = rmouse_btn_stop; break;
            case 0x1C: btn = rmouse_btn_rew; break;
            case 0x1D: btn = rmouse_btn_ff; break;
            default:
               return false; /* not an x10 packet, let the reg mouse take it.*/
         }
         break;
      case 0x45:
         switch(data[1]) {
            case 0x0B: rLastMode = rmouse_mode_phone; break;
            case 0x01: btn = rmouse_btn_one; break;
            case 0x02: btn = rmouse_btn_two; break;
            case 0x03: btn = rmouse_btn_three; break;
            case 0x04: btn = rmouse_btn_four; break;
            case 0x05: btn = rmouse_btn_five; break;
            case 0x06: btn = rmouse_btn_six; break;
            case 0x07: btn = rmouse_btn_seven; break;
            case 0x08: btn = rmouse_btn_eight; break;
            case 0x09: btn = rmouse_btn_nine; break;
            case 0x00: btn = rmouse_btn_zero; break;
            case 0x2B: btn = rmouse_btn_shift; break;
            case 0x0A: btn = rmouse_btn_enter; break;
            case 0x1D: btn = rmouse_btn_axb; break;
            case 0x1C: btn = rmouse_btn_disp; break;
            case 0x0E: btn = rmouse_btn_pause; break;
            case 0x0F: btn = rmouse_btn_last; break;
            case 0x2d: btn = rmouse_btn_guide; break;
            default:
               return false; /* not an x10 packet, let the reg mouse take it.*/
         }
         break;
      case 0x46:
         switch(data[1]) {
            case 0x2B: rLastMode = rmouse_mode_cd; break;
            case 0x0B: rLastMode = rmouse_mode_web; break;
            case 0x13: btn = rmouse_btn_select; break;
            default:
               return false; /* not an x10 packet, let the reg mouse take it.*/
         }
         break;
      case 0x47:
         switch(data[1]) {
            case 0x0B: rLastMode = rmouse_mode_dvd; break;
            case 0x3F: btn = rmouse_btn_rec; break;
            default:
               return false; /* not an x10 packet, let the reg mouse take it.*/
         }
         break;
   }

   BMessage *event = new BMessage( B_MOUSE_MOVED );

   event->AddInt64( "when", system_time() );
   event->AddInt32( "modifiers", ::modifiers() );
   event->AddInt32( "x", 0); /* sneaky trick, doesn't move the mouse anywhere */
   event->AddInt32( "y", 0); /* but gets the remote buttons up to apps. */
   event->AddInt32( "Rmouse mode", rLastMode );
   event->AddInt32( "Rmouse button", btn );

   EnqueueMessage( event );

   return true;
}
