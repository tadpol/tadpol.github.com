/*
Copyright 2000, Micheal Conrad Tilstra, Tadpol.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions, and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions, and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

3. The name of the author may not be used to endorse or promote products
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE AUTHOR "AS IS" AND ANY EXPRESS OR
IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
OF TITLE, NON-INFRINGEMENT, MERCHANTABILITY AND FITNESS FOR A PARTICULAR
PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY
DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR
TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.    

*/
/* this is gonna become a InputDeviec for the x10 mouse remote. */
#ifndef __Rmouse_H__
#define __Rmouse_H__

#include <add-ons/input_server/InputServerDevice.h>
#include <List.h>
#include <OS.h>
#include <SupportDefs.h>

/* perhaps move some of this into a different header file to make it easier
 * to include for people that want to use the remotemouse actions?
 */
typedef enum {
   rmouse_mode_null, /* no mode set */
   rmouse_mode_pc,
   rmouse_mode_cd,
   rmouse_mode_web,
   rmouse_mode_dvd,
   rmouse_mode_phone
} rmouse_modes;

typedef enum {
   rmouse_btn_null, /* no button pushed */
   rmouse_btn_power,
   rmouse_btn_vol_up,
   rmouse_btn_vol_down,
   rmouse_btn_chan_up,
   rmouse_btn_chan_down,
   rmouse_btn_mute,
   rmouse_btn_play,
   rmouse_btn_stop,
   rmouse_btn_rew,
   rmouse_btn_ff,
   rmouse_btn_one,
   rmouse_btn_two,
   rmouse_btn_three,
   rmouse_btn_four,
   rmouse_btn_five,
   rmouse_btn_six,
   rmouse_btn_seven,
   rmouse_btn_eight,
   rmouse_btn_nine,
   rmouse_btn_zero,
   rmouse_btn_shift,
   rmouse_btn_enter,
   rmouse_btn_axb,
   rmouse_btn_disp,
   rmouse_btn_pause,
   rmouse_btn_last,
   rmouse_btn_guide,
   rmouse_btn_select,
   rmouse_btn_rec
} rmouse_buttons;


class Rmouse : public BInputServerDevice
{
   public:
      Rmouse();
#if 0
      ~Rmouse();
#endif

      virtual status_t Start(const char *device, void *);
      virtual status_t Stop(const char *, void *);

   private:
      static int32 UserThread( void *arg);
      bool do_remote_button( char *data );
      status_t do_mouse_action( int32 what, int32 btns );
      status_t sendMouseMessage( int32 what, int32 btn, int x, int y );

   private:
      thread_id rThrd;
      bool rThrdWorking;

      char rSerialPort[20]; /* as in `serial?' */
      rmouse_modes rLastMode;

      bigtime_t rLastClickTime;
      int rLastClickCount;
};


#endif /*__Rmouse_H__*/
