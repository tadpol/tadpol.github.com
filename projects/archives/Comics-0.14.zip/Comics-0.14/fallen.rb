#!/usr/bin/ruby

require 'scrax'
require 'hpricot'

sc = Scrax::Scrax.new('Fallen', 'http://www.fallencomic.com/fal-page.htm',
    'base'=>'http://www.fallencomic.com/')
# this page is just weird.
sc.if_changed do |data|
    sc.replace []
    part = ''; chapter = ''; chn = 0
    doc = Hpricot(data.gsub(%r{</?font.*?>}i,'')) # someone went crazy with font tags...
    (doc/"a[@href^='pages/']").each do |e|
        title = e.inner_html.strip.gsub(/\n|\r/,'').squeeze(' ')
        if title =~ /^Part/i
            part = title
            chn = 0
        end
        unless title =~ /\d/
            chapter = title
            chn += 1
        end
        id = "%d%02d%03d" % [part.scan(/\d+/)[0].to_i, chn, title.scan(/\d+/)[0].to_i]
        title = '' if title == part or title == chapter
        sc << Scrax::RSSItem.new("#{part} #{chapter} #{title}", sc['base']+e['href'], id.to_i)
    end
end

sc.limit
puts sc.to_rss
