#!/usr/bin/ruby

require 'scrax'

sc = Scrax::Scrax.new('Mac Hall', 'http://www.machall.com/',
    'base' => 'http://www.machall.com/index.php?strip_id=',
    'home' => 'http://www.machall.com/')
sc.optionlist
sc.limit
puts sc.to_rss
