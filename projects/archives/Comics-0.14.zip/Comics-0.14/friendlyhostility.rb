#!/usr/bin/ruby

require 'scrax'

sc = Scrax::Scrax.new('Friendly Hostility', 'http://friendlyhostility.com/archive.html',
    'base' => 'http://friendlyhostility.com')
sc.calendarpage
sc.limit
puts sc.to_rss
