#!/usr/bin/ruby

require 'scrax'

sc = Scrax::Scrax.new('Zebra Girl', 'http://zebragirl.keenspot.com/archives.html', 
    'base' => 'http://zebragirl.keenspot.com/' )
sc.calendarpage
sc.limit
puts sc.to_rss
