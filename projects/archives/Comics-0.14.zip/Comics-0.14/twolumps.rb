#!/usr/bin/ruby

require 'scrax'

sc = Scrax::Scrax.new('Two Lumps', 'http://www.twolumps.net/',
    'base' => 'http://www.twolumps.net')
sc.if_changed do |data|
    sc.replace sc.scan_for_keencalendars(data)
end
puts sc.to_rss
