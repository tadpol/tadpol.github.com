#!/usr/bin/ruby

require 'scrax'
require 'hpricot'

sc = Scrax::Scrax.new('Catharsis', 'http://www.catharsiscomic.com/',
    'home' => 'http://www.catharsiscomic.com/',
    'base' => 'http://www.catharsiscomic.com/archive.php?strip=',
    'date_pattern'=> :YYMMDD )
#sc.optionlist
# nothing like switching from YYMMDD to MMDDYY part way through the list.
# lucky us that all we want is the YYMMDD parts.  So use sneaky limiting trick...
sc.if_changed do |data|
    doc = Hpricot(data)
    (doc/"//select[@name='strip']/option")[0..31].each do |e|
        sc << sc.build_item(e.inner_html, sc['base'] + e['value'])
    end
end
sc.limit
puts sc.to_rss
