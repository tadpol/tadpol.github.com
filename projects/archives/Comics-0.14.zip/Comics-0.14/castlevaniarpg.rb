#!/usr/bin/ruby

require 'scrax'

sc = Scrax::Scrax.new('Castlevania RPG', 'http://www.cvrpg.com/main.php',
    'base'=>'http://www.cvrpg.com/')
sc.anchorlist('comics/comic\d+.php')
puts sc.to_rss
