#!/usr/bin/ruby

require 'scrax'


sc = Scrax::Scrax.new('Alien Dice', 'http://www.aliendice.com/')
sc.calendarpage
puts sc.to_rss
