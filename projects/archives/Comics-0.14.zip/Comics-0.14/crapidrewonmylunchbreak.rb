#!/usr/bin/ruby

require 'scrax'

sc = Scrax::Scrax.new('Crap I Drew on My Lunch Break', 'http://crap.jinwicked.com/',
    'base' => 'http://crap.jinwicked.com/?comic=')
sc.optionlist
sc.limit
puts sc.to_rss
