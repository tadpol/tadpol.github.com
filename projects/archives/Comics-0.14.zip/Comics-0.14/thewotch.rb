#!/usr/bin/ruby

require 'scrax'
require 'hpricot'

sc = Scrax::Scrax.new('The Wotch', 'http://thewotch.com/')
sc.if_changed do |data|
	sc.replace []
	doc = Hpricot(data)
	(doc/"area[@href^='http://www.thewotch.com']").each do |e|
		e['href'] =~ /\?epDate=(\d\d\d\d)-(\d\d)-(\d\d)$/
		title = "#{$1}-#{$2}-#{$3}"
#		sc << Scrax::RSSItem.new(title, e['href'])
		sc << {:title=>title, :link=>e['href']}
	end
end
puts sc.to_rss
