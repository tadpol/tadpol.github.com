#!/usr/bin/ruby

require 'scrax'

sc = Scrax::Scrax.new('SkyFall', 'http://www.skyfallmanga.com/archive.html',
    'base' => 'http://www.skyfallmanga.com/')
sc.anchorlist('-p\d+.html')
sc.limit
puts sc.to_rss
