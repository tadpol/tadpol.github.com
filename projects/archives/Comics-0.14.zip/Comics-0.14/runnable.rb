#!/usr/bin/ruby
# darcs doesn't maintain the +x
(Dir['*.rb'] - ['runnable.rb', 'scrax.rb']).each {|i| File.new(i).chmod(0744)}
