#!/usr/bin/ruby

require 'scrax'

sc = Scrax::Scrax.new('DMFA', 'http://www.missmab.com/arch.php',
    'base' => 'http://www.missmab.com/',
    'artc_base' => 'http://www.missmab.com/Comics/' )
sc.chaptered_anchor_list('Comics/Arch_\d+.php', 'Vol_\d+.php')
sc.limit
puts sc.to_rss
