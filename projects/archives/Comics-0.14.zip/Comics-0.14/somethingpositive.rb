#!/usr/bin/ruby

require 'scrax'

sc = Scrax::Scrax.new('Something Positive', 'http://www.somethingpositive.net/archive.shtml',
    'base' => 'http://www.somethingpositive.net/',
    'date_pattern' => :MMDDYYYY) # fails to match date in title, but matches date in link, which is better.
sc.anchorlist('sp\d+\.shtml', 'a')
sc.limit
puts sc.to_rss
