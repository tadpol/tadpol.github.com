#!/usr/bin/ruby

require 'scrax'

sc = Scrax::Scrax.new('The Order of the Stick', 'http://www.giantitp.com/comics/oots.html',
    'base' => 'http://www.giantitp.com',
    'home' => 'http://www.giantitp.com/comics/')
sc.anchorlist('/comics/oots\d+.html')
sc.limit
puts sc.to_rss
