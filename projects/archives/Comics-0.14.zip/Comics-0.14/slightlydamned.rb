#!/usr/bin/ruby

require 'scrax'

sc = Scrax::Scrax.new('Slightly Damned',
	'http://www.raizap.com/sdamned/comics/index.htm',
	'base'=>'http://www.raizap.com/sdamned/comics/',
	'home'=>'http://www.raizap.com/sdamned/index.htm')
sc.anchorlist('\d+\.htm')
sc.limit
puts sc.to_rss
