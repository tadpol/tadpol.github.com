#!/usr/bin/ruby

require 'scrax'
require 'cgi'

sc = Scrax::Scrax.new('Paradox Lost', 'http://paradox-lost.com/scr/archive2.js',
	'date_pattern' => Scrax::DatePattern.new(%r{(\d\d?)/(\d\d?)/(\d\d)}, :MDY) # M/D/YY, MM/DD/YY
	)
sc.if_changed do |data|
    sc.replace []
    data.scan(%r{option[^>]+value=["']([^'"]*)[^>]*>([^<]*)}i) do |value, text|
        if value.length > 1
            value = 'http://paradox-lost.com/' + value unless value =~ /^http/
            text = CGI.unescapeHTML(text.strip).gsub(/&nbsp;/,'')
            sc << sc.build_item(text.strip, value )
        end
    end
end
sc.limit
puts sc.to_rss
