#!/usr/bin/ruby

require 'scrax'

sc = Scrax::Scrax.new('Sequential Art', 'http://www.collectedcurios.com/sequentialart.html',
 'base' => 'http://www.collectedcurios.com/')
sc.anchorlist('SA_\d+_small.jpg')
puts sc.to_rss
