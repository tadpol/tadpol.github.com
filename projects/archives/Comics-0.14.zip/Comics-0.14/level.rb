#!/usr/bin/ruby

require 'scrax'

sc = Scrax::Scrax.new('leveL', 'http://www.levelmanga.com/comic.php',
    'base' => 'http://www.levelmanga.com/')
sc.anchorlist('level.php\?page=\d+\&episode=\d+', 'a')
sc.limit
puts sc.to_rss
