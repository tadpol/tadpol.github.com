#!/usr/bin/ruby

require 'scrax'

sc = Scrax::Scrax.new('Questionable Content', 'http://www.questionablecontent.net/archive.php',
    'base' => 'http://www.questionablecontent.net/')
sc.anchorlist('view.php\?comic=\d+')
sc.limit
puts sc.to_rss
