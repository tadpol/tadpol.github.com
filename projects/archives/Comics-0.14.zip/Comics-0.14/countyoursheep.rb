#!/usr/bin/ruby

require 'scrax'
require 'hpricot'

sc = Scrax::Scrax.new('Count Your Sheep', 'http://www.countyoursheep.com/')
sc.if_changed(sc['uri']) do |data|
	doc = Hpricot(data)
	yesterdaylink = (doc/"//img[@name='previous_day']/../../")[0]['href']
	sc.if_changed(sc['home'] + yesterdaylink) do |data|
		sc.replace sc.scan_for_keencalendars(data)
	end
	sc.remove_dino_uris
end
puts sc.to_rss
