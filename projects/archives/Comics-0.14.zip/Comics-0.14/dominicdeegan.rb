#!/usr/bin/ruby

require 'scrax'

sc = Scrax::Scrax.new('Dominic Deegan', 'http://www.dominic-deegan.com/archive.php',
	'base'=>'http://www.dominic-deegan.com/')
sc.anchorlist('view.php\?date=\d{4}-\d\d-\d\d')
sc.limit
puts sc.to_rss
